#pragma once
#include "Player.h"

class Enemy:public Player
{
public:

    int ENEMY_WIDTH;
    int ENEMY_HEIGHT;

    Enemy(LTexture*);
    LTexture* enemytexture;
    void move();
    void runRender(int camx, SDL_Rect r,SDL_Renderer* gRenderer);
};
