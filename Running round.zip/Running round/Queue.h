#pragma once
#include"Node.h"

class Queue
{
private:
    Node* head;
    Node* tail;
    float speed;
public:
    Queue(float);
    ~Queue();
    void Enqueue(Unit*);
    void Clean();
    void Render(SDL_Renderer* gRenderer);
    void MoveRight();
    void MoveLeft();
    void Move(float);
    int GetLength();
    void Check(float);
};
