#include "Screen.h"
Screen::Screen(LTexture* bgImage,LTexture* fontSprite)
{
    this->fontSprite = fontSprite;
}
Screen::~Screen()
{
    //deallocating pointer
    if (buttons != NULL)
    {
        delete[] buttons;
        buttons = NULL;
    }
    std::cout <<  "Screen destructed" << std::endl;
}
Button* Screen::getButtons()  //returns array of buttons
{
    return buttons;
}
int Screen::getButtonCount() //return the no. of buttons rendered
{
    return ButtonCount;
}
void Screen::ChangeButtonState(State val, int ind) //changes the state of Button on the index
{
    buttons=0;
    buttons[ind].changeState(val);
}
void Screen::mouseMotionEvents(SDL_Event* e, SDL_Renderer* gRenderer)
{
    for(int i=0; i < ButtonCount; i++)
    {
        buttons[i].handleEvent(e,gRenderer);
    }
}

