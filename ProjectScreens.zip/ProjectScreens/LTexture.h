#pragma once
#include "string"
#include "iostream"
#include "SDL.h"
#include "SDL_image.h"
#include <stdio.h>

class LTexture
{
private:
    SDL_Texture* mTexture;
    int mWidth; ///image width
    int mHeight; ///image height

public:
    LTexture();
    ~LTexture();
    bool loadFromFile( std::string path, SDL_Renderer* gRenderer);
    void free();
    void render( int x, int y, SDL_Renderer* gRenderer, SDL_Rect* clip);
    int getWidth();
    int getHeight();
    void setWidth(int);
    void setHeight(int);
    void SetColor( Uint8 red, Uint8 green, Uint8 blue );
    void SetBlendMode( SDL_BlendMode blending );
    void SetAlpha( Uint8 alpha );

};
