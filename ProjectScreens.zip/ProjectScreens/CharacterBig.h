#pragma once
#include "SDL.h"
#include "SDL_image.h"
#include "iostream"
#include "string"
#include "CharacterBig.h"
#include "LTexture.h"
using namespace std;

class CharacterBig ///for the bigger font on the menu and gameover screens.
{
private:
    int x,y;
    SDL_Rect charRect;
    char shownChar;
    int character_value = 0;
    LTexture* CharTexture; ///image texture.
public:
    CharacterBig();
    CharacterBig(LTexture* gSpriteSheetTexture, char c, int x_pos, int y_pos);
    void render(SDL_Renderer* gRenderer);
    void setPosition(int x, int y);
    void setChar(char c);
    void setCharBig(char c);
    void setTexture(char c, LTexture* gSpriteSheetTexture, int x_pos, int y_pos);


};

