#include "gameover.h"
gameoverScreen::gameoverScreen(LTexture* bgImage, LTexture* fontSprite,LTexture* buttonScreen) : Screen(bgImage,fontSprite)
{
    this->bgImage = bgImage;
    this->buttonScreen = buttonScreen;
    std::string ButtonText[3]={"RESTART", "  LOAD  ","  QUIT  "}; //Text on the buttons
    float posX=width/2-150;
    float posY=height/2-200;
    ButtonCount = 3;
    buttons = new Button[3];
    for(int i=0; i<ButtonCount; i++)
    {
        buttons[i] = Button(fontSprite,ButtonText[i],posX, posY + 100);
        posY+=100;
    }

}

void gameoverScreen::Render(long int& frame,SDL_Renderer* gRenderer)
{
    bgImage->render( 0, 0,gRenderer, NULL);
    //buttonScreen->render(0,0,gRenderer,NULL);
    for(int i=0; i<ButtonCount; i++)
    {
        buttons[i].Render(gRenderer);
    }
}

gameoverScreen::~gameoverScreen()
{
    std::cout<<"Game Over Screen Destroyed"<<endl;
}
