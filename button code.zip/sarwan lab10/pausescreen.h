#pragma once
#include "Screen.h"

class pauseScreen:public Screen
{
private:
    LTexture* buttonScreen; //the small screen over which buttons are drawn
public:
    pauseScreen(LTexture*,LTexture*,LTexture*);
    void Render(long int& frame,SDL_Renderer*);
    virtual ~pauseScreen();
};

