#include "Unit.h"
#include <time.h>
#include <cstdlib>

Unit::Unit()
{
}

Unit::Unit(LTexture* image,SDL_Rect r,float x,float y)
{
    this->x=x;
    this->y=y;
    spriteSheetTexture = image;
    src=r;
    friction = 0.95f;
    speedx = 0;
    speedy = 0;
    alive  = true;
    //int w, h;
    //SDL_QueryTexture(image->texture, NULL, NULL, &w, &h);
    //this->width=w;
    //this->height=h;

}


Unit::~Unit()
{
    cout<<"Unit Deallocated"<<endl;
    spriteSheetTexture = NULL;
}

void Unit::SetAlive(bool alive)
{
    this->alive = alive;
}

bool Unit::GetAlive()
{
    return alive;
}

float Unit::GetX()
{
    return x;
}
float Unit::GetY()
{
    return y;
}

void Unit::Move()
{
    //cout<<"Y";
     if(x < -600)
     {
        SetAlive(false);
     }
}

void Unit::Move(int d)
{
   // cout<<"R"<<endl;
    x=x+d;
//
//    if(direction==1)
//    {
//        //speedx = -5;
//        //x+=speedx;
//        x=x-5;
//
//    }
//
//    if(direction==2)
//    {
//        x=x+5;
//        //speedx = 5;
//        //x+=speedx;
//    }
//
//    if(direction==3)
//    {
//        speedy = -5;
//        y+=speedy;
//    }
//
//    if(direction==4)
//    {
//        speedy = 5;
//        y+=speedy;
//    }
//
}

//void Unit::Draw(SDL_Renderer* gRenderer, SDL_Rect rec)
//{
//    mover.x = x;
//    mover.y = y;
//    mover.w = rec.w;
//    mover.h = rec.h;
//    srand(time(NULL));
//    //int k = rand() % 10;
//    SDL_RenderCopy( gRenderer, image, &rec, &mover );
//}

void Unit::Render(SDL_Renderer* gRenderer)
{
 //   cout<<"P";
    spriteSheetTexture->Render( x, y, &src, 0.0, NULL, SDL_FLIP_NONE, gRenderer );
}
