#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <string>
#include <time.h>
#include <cstdlib>
#include "LTexture.h"
#include "Unit.h"
#include "Queue.h"
//Screen dimension constants
const int LEVEL_WIDTH = 1000;
const int LEVEL_HEIGHT = 600;
//Screen dimension constants
const int SCREEN_WIDTH = 800;
const int SCREEN_HEIGHT = 600;
int frame = 0;
int base = 435;
//Starts up SDL and creates window
bool init();

//Loads media
bool loadMedia();

//Frees media and shuts down SDL
void close();

//Loads individual image as texture
SDL_Texture* loadTexture( std::string path );

//The window we'll be rendering to
SDL_Window* gWindow = NULL;

//The window renderer
SDL_Renderer* gRenderer = NULL;
SDL_Rect srcRect[8];
SDL_Rect build[9];
SDL_Rect renderquad[5];
LTexture ggTexture;
LTexture ch_texture;
LTexture tb_texture;
SDL_Texture* gTexture = NULL;

LTexture building1;
LTexture teentalwar;
LTexture hbl;
LTexture chaarMinar;
LTexture altafHussain;

class LTimer
{
    public:
		//Initializes variables
		LTimer();

		//The various clock actions
		void start();
		void stop();
		void pause();
		void unpause();

		//Gets the timer's time
		Uint32 getTicks();

		//Checks the status of the timer
		bool isStarted();
		bool isPaused();

    private:
		//The clock time when the timer started
		Uint32 mStartTicks;

		//The ticks stored when the timer was paused
		Uint32 mPausedTicks;

		//The timer status
		bool mPaused;
		bool mStarted;
};

class Player
{
    public:
		//The dimensions of the dot
		static const int PLAYER_WIDTH = 20;
		static const int PLAYER_HEIGHT = 20;

		//Maximum axis velocity of the dot
		static const float PLAYER_VEL = 0.5;


		//Initializes the variables
		Player();

		//Takes key presses and adjusts the dot's velocity
		void handleEvent( SDL_Event& e );

		//Moves the dot
		void move();
		void jump();
		void fall();
		bool checkJump;

		//Shows the dot on the screen
		void runRender();
		void standRender();

		bool checkRun(SDL_Event& e);
		bool isJump(SDL_Event& e);

		//The X and Y offsets of the dot
		float mPosX, mPosY;

		//The velocity of the dot
		float mVelX, mVelY;
};
LTexture gSpriteSheetTexture;
const int WALKING_ANIMATION_FRAMES = 6;
SDL_Rect gSpriteClips[ WALKING_ANIMATION_FRAMES ];


Player::Player()
{
    //Initialize the offsets
    mPosX = 0;
    mPosY = base;

    //Initialize the velocity
    mVelX = 0;
    mVelY = 0;

    checkJump = false;

}

void Player::handleEvent( SDL_Event& e )
{
    //If a key was pressed
	if( e.type == SDL_KEYDOWN && e.key.repeat == 0 )
    {
        //Adjust the velocity
        switch( e.key.keysym.sym )
        {
            case SDLK_DOWN: mVelY += PLAYER_VEL; break;
            case SDLK_LEFT: mVelX -= PLAYER_VEL; break;
            case SDLK_RIGHT: mVelX += PLAYER_VEL; break;
        }
    }
    //If a key was released
    else if( e.type == SDL_KEYUP && e.key.repeat == 0 )
    {
        //Adjust the velocity
        switch( e.key.keysym.sym )
        {
            case SDLK_DOWN: mVelY -= PLAYER_VEL; break;
            case SDLK_LEFT: mVelX += PLAYER_VEL; break;
            case SDLK_RIGHT: mVelX -= PLAYER_VEL; break;
        }
    }
}

void Player::move()
{
    //Move the dot left or right
    if (mPosY == base)
    {
        mPosX += mVelX;
    }


    //If the dot went too far to the left or right
    if(( mPosX < 0 ) || ( mPosX + PLAYER_WIDTH > SCREEN_WIDTH ))
    {
        //Move back
        mPosX -= mVelX;
    }

    //Move the dot up or down
    //mPosY += mVelY;

    //If the dot went too far up or down
    if( ( mPosY < 0 ) || ( mPosY + PLAYER_HEIGHT > SCREEN_HEIGHT ) )
    {
        //Move back
        mPosY -= mVelY;
    }
}

void Player::jump()
{
    //mPosY = -50;

    mPosY-=2;

    //mPosY += mVelY;
}

void Player::fall()
{


    mPosY+=2;

   // mPosY += mVelY;
}

bool Player::checkRun(SDL_Event& e)
{
    bool run = false;
    if( e.type == SDL_KEYDOWN)
    {
        run = true;
    }
    //If a key was released
    else if( e.type == SDL_KEYUP)
    {
        run = false;
    }
    return run;
}

bool Player::isJump(SDL_Event& e)
{

    if( e.type == SDL_KEYDOWN)
    {
        //Adjust the velocity
        switch( e.key.keysym.sym )
        {
            case SDLK_UP: checkJump = true; break;
        }
    }
    //If a key was released

    return checkJump;
}

void Player::runRender()
{
    //Current animation frame
    SDL_Rect* currentClip = &gSpriteClips[ frame / 6 ];
    gSpriteSheetTexture.Render( mPosX,mPosY, currentClip, 0.0, NULL, SDL_FLIP_NONE, gRenderer  );
}

void Player::standRender()
{
    SDL_Rect* currentClip = &gSpriteClips[0];
    gSpriteSheetTexture.Render( mPosX,mPosY, currentClip, 0.0, NULL, SDL_FLIP_NONE, gRenderer  );
}


bool init()
{
	//Initialization flag
	bool success = true;

	//Initialize SDL
	if( SDL_Init( SDL_INIT_VIDEO ) < 0 )
	{
		printf( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
		success = false;
	}
	else
	{
		//Set texture filtering to linear
		if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) )
		{
			printf( "Warning: Linear texture filtering not enabled!" );
		}

		//Create window
		gWindow = SDL_CreateWindow( "SDL Tutorial", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
		if( gWindow == NULL )
		{
			printf( "Window could not be created! SDL Error: %s\n", SDL_GetError() );
			success = false;
		}
		else
		{
			//Create renderer for window
			gRenderer = SDL_CreateRenderer( gWindow, -1, SDL_RENDERER_ACCELERATED );
			if( gRenderer == NULL )
			{
				printf( "Renderer could not be created! SDL Error: %s\n", SDL_GetError() );
				success = false;
			}
			else
			{
				//Initialize renderer color
				SDL_SetRenderDrawColor( gRenderer, 0, 0, 0, 0);

				//Initialize PNG loading
				int imgFlags = IMG_INIT_PNG;
				if( !( IMG_Init( imgFlags ) & imgFlags ) )
				{
					printf( "SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError() );
					success = false;
				}
			}
		}
	}

	return success;
}

bool loadMedia()
{
	//Loading success flag
	bool success = true;

	//Load PNG texture
	gTexture = loadTexture( "Final_bg.png" );
	if( gTexture == NULL )
	{
		printf( "Failed to load texture image!\n" );
		success = false;
	}

    if (!ggTexture.LoadFromFile("imageedit_1_6941308360.png",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
    else
    {
        srcRect[0].x = 0;
        srcRect[0].y = 0;
        srcRect[0].w = ggTexture.GetWidth();
        srcRect[0].h = ggTexture.GetHeight();

    }
    if (!ch_texture.LoadFromFile("chair_5.png",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
    else
    {
        srcRect[1].x = 0;
        srcRect[1].y = 0;
        srcRect[1].w = ch_texture.GetWidth();
        srcRect[1].h = ch_texture.GetHeight();

    }
    if (!tb_texture.LoadFromFile("table_4.png",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
    else
    {
        srcRect[2].x = 0;
        srcRect[2].y = 0;
        srcRect[2].w = tb_texture.GetWidth();
        srcRect[2].h = tb_texture.GetHeight();
    }

    if (!chaarMinar.LoadFromFile("chaarminar.png",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
    else
    {
     renderquad[1] = {0,0,chaarMinar.GetWidth(),chaarMinar.GetHeight()};
    }
    if (!hbl.LoadFromFile("hbl.png",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
    else
    {
     renderquad[2] = {0,0,hbl.GetWidth(),450};
    }

    if (!altafHussain.LoadFromFile("bhai.gif",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
    else
    {
     renderquad[3] = {0,0,altafHussain.GetWidth(),altafHussain.GetHeight()};
    }

	if (!teentalwar.LoadFromFile("teentalwar.png",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
    else
    {
     renderquad[4] = {0,0,teentalwar.GetWidth(),teentalwar.GetHeight()};
    }

    if( !gSpriteSheetTexture.LoadFromFile( "running.png",gRenderer) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	else
	{
		//Set sprite clips
		gSpriteClips[ 0 ].x =   33;
		gSpriteClips[ 0 ].y =   12;
		gSpriteClips[ 0 ].w =   62;
		gSpriteClips[ 0 ].h =   100;

		gSpriteClips[ 1 ].x =  95;
		gSpriteClips[ 1 ].y =  12;
		gSpriteClips[ 1 ].w =  62;
		gSpriteClips[ 1 ].h =  100;

		gSpriteClips[ 2 ].x = 157;
		gSpriteClips[ 2 ].y = 12;
		gSpriteClips[ 2 ].w = 62;
		gSpriteClips[ 2 ].h = 100;

		gSpriteClips[ 3 ].x = 30;
		gSpriteClips[ 3 ].y = 120;
		gSpriteClips[ 3 ].w = 62;
		gSpriteClips[ 3 ].h = 100;

        gSpriteClips[ 4 ].x = 92;
		gSpriteClips[ 4 ].y = 120;
		gSpriteClips[ 4 ].w = 62;
		gSpriteClips[ 4 ].h = 100;

		gSpriteClips[ 5 ].x = 154;
		gSpriteClips[ 5 ].y = 120;
		gSpriteClips[ 5 ].w = 62;
		gSpriteClips[ 5 ].h = 100;
	}

	return success;
}

void close()
{
	//Free loaded image
	SDL_DestroyTexture( gTexture );
	gTexture = NULL;

	//Destroy window
	SDL_DestroyRenderer( gRenderer );
	SDL_DestroyWindow( gWindow );
	gWindow = NULL;
	gRenderer = NULL;

	//Quit SDL subsystems
	IMG_Quit();
	SDL_Quit();
}

SDL_Texture* loadTexture( std::string path )
{
	//The final texture
	SDL_Texture* newTexture = NULL;

	//Load image at specified path
	SDL_Surface* loadedSurface = IMG_Load( path.c_str() );
	if( loadedSurface == NULL )
	{
		printf( "Unable to load image %s! SDL_image Error: %s\n", path.c_str(), IMG_GetError() );
	}
	else
	{
		//Create texture from surface pixels
        newTexture = SDL_CreateTextureFromSurface( gRenderer, loadedSurface );
		if( newTexture == NULL )
		{
			printf( "Unable to create texture from %s! SDL Error: %s\n", path.c_str(), SDL_GetError() );
		}

		//Get rid of old loaded surface
		SDL_FreeSurface( loadedSurface );
	}

	return newTexture;
}

int main( int argc, char* args[] )
{
	//Start up SDL and create window
	if( !init() )
	{
		printf( "Failed to initialize!\n" );
	}
	else
	{
		//Load media
		if( !loadMedia() )
		{
			printf( "Failed to load media!\n" );
		}
		else
		{
			//Main loop flag
			bool quit = false;

			//Event handler
			SDL_Event e;
            SDL_Rect camera = { 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT };
			int cVelX = 0;
			Queue office;

			int z=0;
            int fr=0;
            int a=400;
			bool pressed=false;
			int Count=0;
			int b=0;
			int c=0;
			int d=450;
            int q=400;
            Unit* o;
            for (int i=0;i<2;i++)
            {
                o = new Unit(&ggTexture,srcRect[0],q,390);
                office.Enqueue(o);
                q+=2000;
            }

            int p = 900;
            for (int i=0;i<3;i++)
            {
             o = new Unit(&ch_texture,srcRect[1],p,430);
             office.Enqueue(o);
             p+=1000;
            }

            int w = 1400;
            for (int i=0;i<3;i++)
            {
             o = new Unit(&tb_texture,srcRect[2],w,330);
             office.Enqueue(o);
            w+=1400;
            }



			//While application is running
			Player player;
			while( !quit )
			{
				//Handle events on queue
				while( SDL_PollEvent( &e ) != 0 )
				{
					//User requests quit
					if( e.type == SDL_QUIT )
					{
						quit = true;
					}
					else if( e.type == SDL_KEYDOWN && e.key.repeat == 0 )
                    {
//                        pressed=true;
                    //Adjust the velocity
                        switch( e.key.keysym.sym )
                        {
                            case SDLK_LEFT:
                                pressed=true;
                                cVelX-=2;
                                z=2;
                                break;
                            case SDLK_RIGHT:
                                pressed=true;
                                cVelX+=2;
                                z=-2;
                                break;
                        }
                    }

                    else if( e.type == SDL_KEYUP && e.key.repeat == 0 )
                    {
                    //Adjust the velocity
                        switch( e.key.keysym.sym )
                        {
                            case SDLK_LEFT:
                                pressed=false;
                                cVelX+=2;
                                z=-2;
                                break;
                            case SDLK_RIGHT:
                                pressed=false;
                                cVelX-=2;
                                z=2;
                                break;
                        }
                    }
                    player.handleEvent( e );
					player.isJump(e);
				}

				if ((player.checkJump == true) & (player.mPosY > base - 200))
                {
                    player.jump();
                    if (player.mPosY == base - 200)
                    {
                        player.checkJump = false;
                    }
                }

                else if ((player.checkJump == false) & (player.mPosY < base))
                {
                    player.fall();
                }

                else
                {
                    player.move();
                }
				int w,h;
				SDL_QueryTexture(gTexture,NULL,NULL,&w,&h);

                if ((pressed==true))// & (camera.x < w - camera.w) & (camera.x >0))
                {
                    camera.x += cVelX;
                    //objectList.Move(z);
                    office.Move(z);
                //    v->Move(z);
                    //q->Move(z);
                }
				if( camera.x < 0 )
				{
					camera.x = 0;
					//objectList.Move(-z);
					office.Move(-z);
				}

				if( camera.y < 0 )
				{
					camera.y = 0;
				}

				if(camera.x > w - camera.w)
                {
                    camera.x = w - camera.w;

                }
				if( camera.y > LEVEL_HEIGHT - camera.h )
				{
					camera.y = LEVEL_HEIGHT - camera.h;
				}
                //BGTexture.Render(0,0, &srcRect[0], 0.0, NULL, SDL_FLIP_NONE,gRenderer);
                SDL_RenderPresent( gRenderer );
				//Clear screen
				SDL_RenderClear( gRenderer );

                //Render texture to screen
				SDL_RenderCopy( gRenderer, gTexture, &camera,NULL );
				office.Render(gRenderer);
				office.Move();
				//office.Clean();
                //objectList.Render(gRenderer);
                //objectList.Move();
                //objectList.Clean();
                SDL_Delay(1);
				//Update screen
				//gSpriteSheetTexture.Render(100,100, &srcRect[8], 0.0, NULL, SDL_FLIP_NONE, gRenderer );

				if (player.checkRun(e) == true)
                {
                    player.runRender();
                    ++frame;
                }

                else
                {
                    player.standRender();
                }


				SDL_RenderPresent( gRenderer );
				fr++;
				if( frame / 6 >= WALKING_ANIMATION_FRAMES )
				{
					frame = 0;
				}
			}
		}
	}

	//Free resources and close SDL
	close();

	return 0;
}
