//Using SDL, SDL_image, standard math, and strings
#include <SDL.h>
#include <SDL_image.h>
#include <SDL_mixer.h>
#include <stdio.h>
#include <string>
#include "iostream"
#include "Buttons.h"
#include "menuScreen.h"
#include "Screen.h"
#include "LTexture.h"
#include "Words.h"
#include "gamescreen.h"
#include "pausescreen.h"
#include "gameover.h"

using namespace std;

SDL_Window* gWindow = NULL;
SDL_Renderer* gRenderer = NULL;
SDL_Surface* gScreenSurface = NULL;
SDL_Surface* gBackgroundSurface = NULL;

Mix_Music *gMusic = NULL;
Mix_Chunk *gMedium = NULL;

SDL_Surface* loadSurface( std::string path );
SDL_Texture* addBackground();

LTexture Background;
LTexture ButtonTextureSheet;
LTexture FontTextureSheet;
LTexture GameTextureSheet;
LTexture PauseTextureSheet;


SDL_Rect ButtonTextureClip;
SDL_Rect Backgroundclip;
SDL_Rect Admiclip;


const int SCREEN_WIDTH = 1230;
const int SCREEN_HEIGHT = 540;


bool init()
{
	//Initialization flag
	bool success = true;

	//Initialize SDL
    if( SDL_Init( SDL_INIT_VIDEO ) < 0 )
    {
        printf( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
        success = false;
    }
	else
	{
		//Set texture filtering to linear
		if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) )
		{
			printf( "Warning: Linear texture filtering not enabled!" );
		}

		//Create window
		gWindow = SDL_CreateWindow( "SDL Tutorial", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH-30, SCREEN_HEIGHT-10, SDL_WINDOW_SHOWN );
		if( gWindow == NULL )
		{
			printf( "Window could not be created! SDL Error: %s\n", SDL_GetError() );
			success = false;
		}
		else
		{
			//Create renderer for window
			gRenderer = SDL_CreateRenderer( gWindow, -1, SDL_RENDERER_ACCELERATED );
			if( gRenderer == NULL )
			{
				printf( "Renderer could not be created! SDL Error: %s\n", SDL_GetError() );
				success = false;
			}
			else
			{
				//Initialize renderer color
				SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );

				//Initialize PNG loading
				int imgFlags = IMG_INIT_PNG;
				if( !( IMG_Init( imgFlags ) & imgFlags ) )
				{
					printf( "SDL_image could not initialize! SDL_mage Error: %s\n", IMG_GetError() );
					success = false;
				}

                if( Mix_OpenAudio( 44100, MIX_DEFAULT_FORMAT, 2, 2048 ) < 0 )
                {
                    printf( "SDL_mixer could not initialize! SDL_mixer Error: %s\n", Mix_GetError() );
                    success = false;
                }

                //Get window surface
                gScreenSurface = SDL_GetWindowSurface( gWindow );


			}
		}
	}

	return success;
}



bool loadMedia()
{
    bool success = true;
	if( !Background.loadFromFile( "Background2.png", gRenderer) )
	{
		printf( "Failed to Background sheet texture!\n" );
		success = false;
	}

	if( !FontTextureSheet.loadFromFile( "XiroidFinal2.png", gRenderer) )
	{
		printf( "Failed to load sprite sheet texture!\n" );
		success = false;
	}

    if( !ButtonTextureSheet.loadFromFile( "XiroidFinal2.png", gRenderer) )
	{
		printf( "Failed to load sprite sheet texture!\n" );
		success = false;
	}

    if( !GameTextureSheet.loadFromFile( "newgame.png", gRenderer) )
	{
		printf( "Failed to game sprite sheet texture!\n" );
		success = false;
	}

    if( !PauseTextureSheet.loadFromFile( "pausebg.png", gRenderer) )
	{
		printf( "Failed to pause sprite sheet texture!\n" );
		success = false;
	}

    gMusic = Mix_LoadMUS( "Lounge Game.wav" );

    if( gMusic == NULL )
    {
        printf( "Failed to load beat music! SDL_mixer Error: %s\n", Mix_GetError() );
        success = false;
    }

	gMedium = Mix_LoadWAV( "medium.wav" );
	if( gMedium == NULL )
	{
		printf( "Failed to load medium sound effect! SDL_mixer Error: %s\n", Mix_GetError() );
		success = false;
	}
	else
    {

    }
	return success;
}

void close()
{

	//Destroy window
	Background.free();
    FontTextureSheet.free();
    ButtonTextureSheet.free();

	Mix_FreeChunk( gMedium );
	gMedium = NULL;
    Mix_FreeMusic( gMusic );
    gMusic = NULL;

	SDL_DestroyRenderer( gRenderer );
	SDL_DestroyWindow( gWindow );
	gWindow = NULL;
	gRenderer = NULL;


	//Quit SDL subsystems
	IMG_Quit();
	SDL_Quit();
}


SDL_Surface* loadSurface( std::string path )
{
	//The final optimized image
	SDL_Surface* optimizedSurface = NULL;

	//Load image at specified path
	SDL_Surface* loadedSurface = IMG_Load( path.c_str() );
	if( loadedSurface == NULL )
	{
		printf( "Unable to load image %s! SDL_image Error: %s\n", path.c_str(), IMG_GetError() );
	}
	else
	{
		//Convert surface to screen format
		optimizedSurface = SDL_ConvertSurface( loadedSurface, gScreenSurface->format, NULL );
		if( optimizedSurface == NULL )
		{
			printf( "Unable to optimize image %s! SDL Error: %s\n", path.c_str(), SDL_GetError() );
		}

		//Get rid of old loaded surface
		SDL_FreeSurface( loadedSurface );
	}

	return optimizedSurface;
}


int main( int argc, char* args[] )
{	//Start up SDL and create window
	if( !init() )
	{
		printf( "Failed to initialize!\n" );
	}
	else
	{

		if( !loadMedia() )
		{
			printf( "Failed to load media!\n" );
		}
		else
		{

            long int frame = 0;
            bool mouseClicked=false;
			bool menusc=true;
			bool gamesc=false;
			bool loadsc=false;
			bool pausesc=false;
			bool gameover=false;
			bool quit = false;
			SDL_Event e;
            Word go("GAME OVER!!",&FontTextureSheet,SCREEN_WIDTH/2-270,SCREEN_HEIGHT/2-150,frame);

            menuScreen menu(&Background,&FontTextureSheet,&FontTextureSheet);
            GameScreen gamestart(&GameTextureSheet,&FontTextureSheet,&FontTextureSheet);
            pauseScreen pause(&PauseTextureSheet,&FontTextureSheet,&FontTextureSheet);
            gameoverScreen gamefin(&Background,&FontTextureSheet,&FontTextureSheet);
            SDL_Texture* bgTexture = SDL_CreateTextureFromSurface(gRenderer, gScreenSurface);

//			Button btnstart("START", &FontTextureSheet, &ButtonTextureSheet, ButtonTextureClip, SCREEN_WIDTH/2+200, SCREEN_HEIGHT/2-150, 300, 60);
//			Button btnstart1("START", &FontTextureSheet, &ButtonTextureSheet, ButtonTextureClip, SCREEN_WIDTH/2+200, SCREEN_HEIGHT/2-150, 300, 60);

            //While application is running`
			while( !quit )
			{
				//Handle events on queue
				while( SDL_PollEvent( &e ) != 0 )
				{
					//User requests quit
					if( e.type == SDL_QUIT )
					{
						quit = true;
					}
				//Clear screen
				SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );
				SDL_RenderClear( gRenderer );
				if (menusc)
                {
                    menu.Render(frame,gRenderer);
                    menu.mouseMotionEvents(&e,gRenderer);
                    if( Mix_PlayingMusic() == 0 )
                    {
                        Mix_PlayMusic( gMusic, -1 );
                    }

                    if (menu.getButtons()[0].getstate()==2)///when start game clicked
                    {

                        Mix_PlayChannel( -1, gMedium, 0 );
                        Mix_HaltMusic();
                        menusc=false;
                        gamesc=true;

                    }
                    if (menu.getButtons()[1].getstate()==2) ///when load game clicked
                    {
                        Mix_PlayChannel( -1, gMedium, 0 );
                        loadsc=true;
                        menusc=false;
                    }


                    if (menu.getButtons()[2].getstate()==2) ///when quit is pressed
                    {

                        Mix_PlayChannel( -1, gMedium, 0 );
                        quit=true;
                        cout<<"menu exit"<<endl;
                    }

                }
                if (gamesc) ///gamescreen running
                {
                    gamestart.Render(frame,gRenderer);
                    gamestart.mouseMotionEvents(&e,gRenderer);

                    cout<<"Game screen entered"<<endl;
                    if (gamestart.getButtons()[0].getstate()==2) ///resume button pressed
                    {
                        Mix_PlayChannel( -1, gMedium, 0 );

                        gamesc=false;
                        pausesc=true;
                    }

//
//                }
				}
				if (pausesc) ///pause screen running.
                {
                    pause.Render(frame,gRenderer);
                    pause.mouseMotionEvents(&e,gRenderer);

                    if (pause.getButtons()[0].getstate()==2)
                    {
                        Mix_PlayChannel( -1, gMedium, 0 );

                        gamesc=true;
                        pausesc=false;

                    }

                    if (pause.getButtons()[2].getstate()==2)
                    {
                        Mix_PlayChannel( -1, gMedium, 0 );

                        menusc=true;
                        pausesc=false;
                    }

                }
                if(gameover)
                {

                    gamefin.Render(frame,gRenderer);
                    gamefin.mouseMotionEvents(&e,gRenderer);
                    go.render(gRenderer);
                    if( Mix_PlayingMusic() == 0 )
                    {
                        Mix_PlayMusic( gMusic, -1 );
                    }

                    if(gamefin.getButtons()[2].getstate()==2)
                    {
                        Mix_PlayChannel( -1, gMedium, 0 );


                        gameover=false;
                        menusc=true;
                    }
                    if(gamefin.getButtons()[0].getstate()==2)
                    {
                        Mix_PlayChannel( -1, gMedium, 0 );

                        gameover=false;
                        gamesc=true;
                    }

                }

				SDL_RenderPresent( gRenderer );
			}
		}
	}
	}

	//Free resources and close SDL
	close();

	return 0;
}



