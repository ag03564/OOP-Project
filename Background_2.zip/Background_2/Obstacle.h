#pragma once

#include"Unit.h"

class Obstacle:public Unit
{
public:
    Obstacle(LTexture* image, SDL_Rect r, float x, float y);
    Obstacle();
    virtual ~Obstacle();
//    void SetAlive(bool);
//    bool GetAlive();
//    int GetWidth();
//    int GetHeight();
//    float GetX();
//    float GetY();
    virtual void Move(int direction);
    virtual void Move();
    virtual void Render(SDL_Renderer* gRenderer);
};
