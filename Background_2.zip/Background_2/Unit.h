#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <iostream>
#include "LTexture.h"

using namespace std;

class Unit
{
protected:
    bool alive;
    float x;
    float y;
    float speedx;
    float speedy;
    int width;
    int height;
    float friction; //lower speed means more friction
    SDL_Rect src;
    LTexture* spriteSheetTexture;
public:
        Unit(LTexture* image, SDL_Rect r, int,int);
        Unit();
        virtual ~Unit();
        void SetAlive(bool);
        bool GetAlive();
        int GetWidth();
        int GetHeight();
        float GetX();
        float GetY();
        virtual void Move(float direction);
        virtual void Move();
        virtual void Render(SDL_Renderer* gRenderer);//, bool debug);
};



