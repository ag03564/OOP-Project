#pragma once
#include"Unit.h"

class Vehicle:public Unit
{
    const float speed=0.4;
public:
    Vehicle(LTexture* image, SDL_Rect r, float x, float y);
    Vehicle();
    virtual ~Vehicle();
//    void SetAlive(bool);
//    bool GetAlive();
//    int GetWidth();
//    int GetHeight();
//    float GetX();
//    float GetY();
    virtual void Run();
    virtual void Move(float);
    virtual void Move();
    virtual void Render(SDL_Renderer* gRenderer);
};

