#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <string>
#include <time.h>
#include <cstdlib>
#include "LTexture.h"
#include "Unit.h"
#include "Queue.h"
#include "Obstacle.h"
#include "Vehicle.h"

//Screen dimension constants
const int LEVEL_WIDTH = 1000;
const int LEVEL_HEIGHT = 600;
//Screen dimension constants
const int SCREEN_WIDTH = 800;
const int SCREEN_HEIGHT = 600;
const int jumpHeight = 10;
LTexture gSpriteSheetTexture;
LTexture gSpriteSheetTexture1;
static const int WALKING_ANIMATION_FRAMES = 6;
SDL_Rect gSpriteClips[ WALKING_ANIMATION_FRAMES ];
SDL_Rect gSpriteClips1[ WALKING_ANIMATION_FRAMES ];
int frame = 0;
int frame1 = 0;
int base = 435;
int countt=0;
int countt1=0;
//static const int base = 435;


//Starts up SDL and creates window
bool init();

//Loads media
bool loadMedia();

//Frees media and shuts down SDL
void close();

//Loads individual image as texture
SDL_Texture* loadTexture( std::string path );

//The window we'll be rendering to
SDL_Window* gWindow = NULL;

//The window renderer
SDL_Renderer* gRenderer = NULL;
SDL_Rect srcRect[8];
SDL_Rect build[9];
SDL_Rect cloud,cloud2;
SDL_Rect renderquad[5];
LTexture ggTexture;
LTexture ctexture,c2texture;

SDL_Texture* gTexture = NULL;

LTexture road1;
LTexture building1;
LTexture teentalwar;
LTexture hbl;
LTexture chaarMinar;
LTexture tomb;
LTexture altafHussain;

LTexture vtexture;
SDL_Rect veh[3];

class LTimer
{
    public:
		//Initializes variables
		LTimer();

		//The various clock actions
		void start();
		void stop();
		void pause();
		void unpause();

		//Gets the timer's time
		Uint32 getTicks();

		//Checks the status of the timer
		bool isStarted();
		bool isPaused();

    private:
		//The clock time when the timer started
		Uint32 mStartTicks;

		//The ticks stored when the timer was paused
		Uint32 mPausedTicks;

		//The timer status
		bool mPaused;
		bool mStarted;
};



class Player
{
    public:
		//The dimensions of the dot
		static const int PLAYER_WIDTH = 20;
		static const int PLAYER_HEIGHT = 20;

		//Maximum axis velocity of the dot
		const float PLAYER_VEL = 0.03;
		//Initializes the variables
		Player();

		//Takes key presses and adjusts the dot's velocity
		void handleEvent( SDL_Event& e );

		//Moves the dot
		void move();
		void jump();
		void fall();
		bool checkJump;

		//Shows the dot on the screen
		void runRender();
		void standRender();

		bool checkRun(SDL_Event& e);
		bool isJump(SDL_Event& e);

		//The X and Y offsets of the dot
		float mPosX, mPosY;

		//The velocity of the dot
		float mVelX, mVelY;
};



Player::Player()
{
    //Initialize the offsets
    mPosX = 200;
    mPosY = base;

    //Initialize the velocity
    mVelX = 0;
    mVelY = 0;
    checkJump = false;
}

void Player::handleEvent( SDL_Event& e )
{
    //If a key was pressed
	if( e.type == SDL_KEYDOWN && e.key.repeat == 0 )
    {
        //Adjust the velocity
        switch( e.key.keysym.sym )
        {
            case SDLK_DOWN: mVelY += PLAYER_VEL; break;
            case SDLK_LEFT: mVelX -= PLAYER_VEL; break;
            case SDLK_RIGHT: mVelX += PLAYER_VEL; break;
        }
    }
    //If a key was released
    else if( e.type == SDL_KEYUP && e.key.repeat == 0 )
    {
        //Adjust the velocity
        switch( e.key.keysym.sym )
        {
            case SDLK_DOWN: mVelY -= PLAYER_VEL; break;
            case SDLK_LEFT: mVelX += PLAYER_VEL; break;
            case SDLK_RIGHT: mVelX -= PLAYER_VEL; break;
        }
    }
}

void Player::move()
{
    //Move the dot left or right
    if (mPosY == base)
    {
        mPosX += mVelX;
    }


    //If the dot went too far to the left or right
    if(( mPosX < 0 ) || ( mPosX + PLAYER_WIDTH > SCREEN_WIDTH ))
    {
        //Move back
        mPosX -= mVelX;
    }

    //Move the dot up or down
    //mPosY += mVelY;

    //If the dot went too far up or down
    if( ( mPosY < 0 ) || ( mPosY + PLAYER_HEIGHT > SCREEN_HEIGHT ) )
    {
        //Move back
        mPosY -= mVelY;
    }
}

void Player::jump()
{
    //mPosY = -50;

    mPosY-=2;

    //mPosY += mVelY;
}

void Player::fall()
{


    mPosY+=2;

   // mPosY += mVelY;
}

bool Player::checkRun(SDL_Event& e)
{
    bool run = false;
    if( e.type == SDL_KEYDOWN)
    {
        run = true;
    }
    //If a key was released
    else if( e.type == SDL_KEYUP)
    {
        run = false;
    }
    return run;
}

bool Player::isJump(SDL_Event& e)
{

    if( e.type == SDL_KEYDOWN)
    {
        //Adjust the velocity
        switch( e.key.keysym.sym )
        {
            case SDLK_UP: checkJump = true; break;
        }
    }
    //If a key was released

    return checkJump;
}

void Player::runRender()
{
    //Current animation frame
    SDL_Rect* currentClip = &gSpriteClips[ frame / 6 ];
    gSpriteSheetTexture.Render( mPosX,mPosY, currentClip, 0.0, NULL, SDL_FLIP_NONE, gRenderer  );
}

void Player::standRender()
{

    SDL_Rect* currentClip = &gSpriteClips[5];
    gSpriteSheetTexture.Render( mPosX,mPosY, currentClip, 0.0, NULL, SDL_FLIP_NONE, gRenderer  );
}

class Enemy
{
    public:
		//The dimensions of the dot
		static const int ENEMY_WIDTH = 20;
		static const int ENEMY_HEIGHT = 20;


		//Initializes the variables
		Enemy();

		//Takes key presses and adjusts the dot's velocity
		//void handleEvent( SDL_Event& e );

		//Moves the dot
		void move();
		void jump();
		void fall();
		bool checkJump;

		//Shows the dot on the screen
		void runRender();
		void standRender();

		bool checkRun(SDL_Event& e);
		bool isJump(SDL_Event& e);

		//The X and Y offsets of the dot
		float mPosX, mPosY;

		//The velocity of the dot
		float mVelX, mVelY;
};



Enemy::Enemy()
{
    //Initialize the offsets
    mPosX = 0;
    mPosY = base;

    //Initialize the velocity
    mVelX = 0.03;
    mVelY = 0;
    checkJump = false;
}

/*void Player::handleEvent( SDL_Event& e )
{
    //If a key was pressed
	if( e.type == SDL_KEYDOWN && e.key.repeat == 0 )
    {
        //Adjust the velocity
        switch( e.key.keysym.sym )
        {
            case SDLK_DOWN: mVelY += PLAYER_VEL; break;
            case SDLK_LEFT: mVelX -= PLAYER_VEL; break;
            case SDLK_RIGHT: mVelX += PLAYER_VEL; break;
        }
    }
    //If a key was released
    else if( e.type == SDL_KEYUP && e.key.repeat == 0 )
    {
        //Adjust the velocity
        switch( e.key.keysym.sym )
        {
            case SDLK_DOWN: mVelY -= PLAYER_VEL; break;
            case SDLK_LEFT: mVelX += PLAYER_VEL; break;
            case SDLK_RIGHT: mVelX -= PLAYER_VEL; break;
        }
    }
}*/

void Enemy::move()
{
    //Move the dot left or right
    if (mPosY == base)
    {
        mPosX += mVelX;
    }


    //If the dot went too far to the left or right
    if(( mPosX < 0 ) || ( mPosX + ENEMY_WIDTH > SCREEN_WIDTH ))
    {
        //Move back
        mPosX -= mVelX;
    }

    //Move the dot up or down
    //mPosY += mVelY;

    //If the dot went too far up or down
    if( ( mPosY < 0 ) || ( mPosY + ENEMY_HEIGHT > SCREEN_HEIGHT ) )
    {
        //Move back
        mPosY -= mVelY;
    }
}

void Enemy::jump()
{
    //mPosY = -50;

    mPosY-=2;

    //mPosY += mVelY;
}

void Enemy::fall()
{


    mPosY+=2;

   // mPosY += mVelY;
}

/*bool Enemy::checkRun(SDL_Event& e)
{
    bool run = false;
    if( e.type == SDL_KEYDOWN)
    {
        run = true;
    }
    //If a key was released
    else if( e.type == SDL_KEYUP)
    {
        run = false;
    }
    return run;
}

bool Player::isJump(SDL_Event& e)
{

    if( e.type == SDL_KEYDOWN)
    {
        //Adjust the velocity
        switch( e.key.keysym.sym )
        {
            case SDLK_UP: checkJump = true; break;
        }
    }
    //If a key was released

    return checkJump;
}
*/
void Enemy::runRender()
{
    //Current animation frame
    SDL_Rect* currentClip = &gSpriteClips[ frame1 / 6 ];
    gSpriteSheetTexture.Render( mPosX,mPosY, currentClip, 0.0, NULL, SDL_FLIP_NONE, gRenderer  );
}

/*void Player::standRender()
{

    SDL_Rect* currentClip = &gSpriteClips[5];
    gSpriteSheetTexture.Render( mPosX,mPosY, currentClip, 0.0, NULL, SDL_FLIP_NONE, gRenderer  );
}
*/
bool init()
{
	//Initialization flag
	bool success = true;

	//Initialize SDL
	if( SDL_Init( SDL_INIT_VIDEO ) < 0 )
	{
		printf( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
		success = false;
	}
	else
	{
		//Set texture filtering to linear
		if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) )
		{
			printf( "Warning: Linear texture filtering not enabled!" );
		}

		//Create window
		gWindow = SDL_CreateWindow( "SDL Tutorial", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
		if( gWindow == NULL )
		{
			printf( "Window could not be created! SDL Error: %s\n", SDL_GetError() );
			success = false;
		}
		else
		{
			//Create renderer for window
			gRenderer = SDL_CreateRenderer( gWindow, -1, SDL_RENDERER_ACCELERATED );
			if( gRenderer == NULL )
			{
				printf( "Renderer could not be created! SDL Error: %s\n", SDL_GetError() );
				success = false;
			}
			else
			{
				//Initialize renderer color
				SDL_SetRenderDrawColor( gRenderer, 0, 0, 0, 0);

				//Initialize PNG loading
				int imgFlags = IMG_INIT_PNG;
				if( !( IMG_Init( imgFlags ) & imgFlags ) )
				{
					printf( "SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError() );
					success = false;
				}
			}
		}
	}

	return success;
}

bool loadMedia()
{
	//Loading success flag
	bool success = true;

	//Load PNG texture
	gTexture = loadTexture( "New Project.jpg" );
	if( gTexture == NULL )
	{
		printf( "Failed to load texture image!\n" );
		success = false;
	}

    if (!ggTexture.LoadFromFile("imageedit_4_2597540840.png",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
    else
    {
        srcRect[0].x = 409;
        srcRect[0].y = 375;
        srcRect[0].w = 110;
        srcRect[0].h = 75;

        srcRect[1].x = 552;
        srcRect[1].y = 385;
        srcRect[1].w = 88;
        srcRect[1].h = 63;

        srcRect[2].x = 427;
        srcRect[2].y = 3;
        srcRect[2].w = 213;
        srcRect[2].h = 165;

        srcRect[3].x = 0;
        srcRect[3].y = 146;
        srcRect[3].w = 395;
        srcRect[3].h = 196;

        srcRect[4].x = 412;
        srcRect[4].y = 176;
        srcRect[4].w = 228;
        srcRect[4].h = 112;

        srcRect[5].x = 409;
        srcRect[5].y = 375;
        srcRect[5].w = 110;
        srcRect[5].h = 75;

        srcRect[6].x = 552;
        srcRect[6].y = 385;
        srcRect[6].w = 88;
        srcRect[6].h = 63;
    }

    if (!road1.LoadFromFile("road.jpeg",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
    else
    {
        srcRect[7].x=30;
        srcRect[7].y=0;
        srcRect[7].w=900;
        srcRect[7].h=230;
    }
    if (!building1.LoadFromFile("buildings.png",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
    else
    {
        build[0].x = 0;
        build[0].y = 35;
        build[0].w = 564;
        build[0].h = 188;

        build[1].x = 27;
        build[1].y = 261;
        build[1].w = 570;
        build[1].h = 136;

        build[2].x = 40;
        build[2].y = 460;
        build[2].w = 556;
        build[2].h = 131;

        build[3].x = 0;
        build[3].y = 200;
        build[3].w = 200;
        build[3].h = 200;

        build[4].x = 200;
        build[4].y = 200;
        build[4].w = 200;
        build[4].h = 200;

        build[5].x = 400;
        build[5].y = 200;
        build[5].w = 200;
        build[5].h = 200;

        build[6].x = 0;
        build[6].y = 400;
        build[6].w = 88;
        build[6].h = 63;

        build[7].x = 200;
        build[7].y = 400;
        build[7].w = 200;
        build[7].h = 200;

        build[8].x = 400;
        build[8].y = 400;
        build[8].w = 200;
        build[8].h = 200;

    }
    if (!tomb.LoadFromFile("tomb.png",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
    else
    {
     renderquad[0] = {0,0,tomb.GetWidth(),tomb.GetHeight()};
    }
    if (!chaarMinar.LoadFromFile("chaarminar.png",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
    else
    {
     renderquad[1] = {0,0,chaarMinar.GetWidth(),chaarMinar.GetHeight()};
    }
    if (!hbl.LoadFromFile("hbl.png",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
    else
    {
     renderquad[2] = {0,0,hbl.GetWidth(),450};
    }

    if (!altafHussain.LoadFromFile("bhai.gif",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
    else
    {
     renderquad[3] = {0,0,altafHussain.GetWidth(),altafHussain.GetHeight()};
    }

	if (!teentalwar.LoadFromFile("teentalwar.png",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
    else
    {
     renderquad[4] = {0,0,teentalwar.GetWidth(),teentalwar.GetHeight()};
    }

    if( !gSpriteSheetTexture.LoadFromFile( "running.png",gRenderer) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	else
    {
           gSpriteClips[ 0 ].x =   33;
		gSpriteClips[ 0 ].y =   12;
		gSpriteClips[ 0 ].w =   62;
		gSpriteClips[ 0 ].h =   100;

		gSpriteClips[ 1 ].x =  95;
		gSpriteClips[ 1 ].y =  12;
		gSpriteClips[ 1 ].w =  62;
		gSpriteClips[ 1 ].h =  100;

		gSpriteClips[ 2 ].x = 157;
		gSpriteClips[ 2 ].y = 12;
		gSpriteClips[ 2 ].w = 62;
		gSpriteClips[ 2 ].h = 100;

		gSpriteClips[ 3 ].x = 30;
		gSpriteClips[ 3 ].y = 120;
		gSpriteClips[ 3 ].w = 62;
		gSpriteClips[ 3 ].h = 100;

        gSpriteClips[ 4 ].x = 92;
		gSpriteClips[ 4 ].y = 120;
		gSpriteClips[ 4 ].w = 62;
		gSpriteClips[ 4 ].h = 100;

		gSpriteClips[ 5 ].x = 154;
		gSpriteClips[ 5 ].y = 120;
		gSpriteClips[ 5 ].w = 62;
		gSpriteClips[ 5 ].h = 100;
    }

	if(!vtexture.LoadFromFile("Vehicle_3.png",gRenderer))
    {
        printf( "Failed to load dot texture!\n" );
		success = false;
	}
	else
    {

        veh[1].x= 280;
        veh[1].y= 100;
        veh[1].w= 250;
        veh[1].h= 300;

        veh[2].x= 0;
        veh[2].y= 100;
        veh[2].w= 280;
        veh[2].h= 300;
    }

    if(!c2texture.LoadFromFile("10-cloud-png-image-thumb.png",gRenderer))
    {
        printf( "Failed to load dot texture!\n" );
		success = false;
	}
	else
    {
        cloud2.x=0;
        cloud2.y=0;
        cloud2.w=c2texture.GetWidth();
        cloud2.h=c2texture.GetHeight();
    }

	return success;
}

void close()
{
	//Free loaded image
	SDL_DestroyTexture( gTexture );
	gTexture = NULL;

	//Destroy window
	SDL_DestroyRenderer( gRenderer );
	SDL_DestroyWindow( gWindow );
	gWindow = NULL;
	gRenderer = NULL;

	//Quit SDL subsystems
	IMG_Quit();
	SDL_Quit();
}

SDL_Texture* loadTexture( std::string path )
{
	//The final texture
	SDL_Texture* newTexture = NULL;

	//Load image at specified path
	SDL_Surface* loadedSurface = IMG_Load( path.c_str() );
	if( loadedSurface == NULL )
	{
		printf( "Unable to load image %s! SDL_image Error: %s\n", path.c_str(), IMG_GetError() );
	}
	else
	{
		//Create texture from surface pixels
        newTexture = SDL_CreateTextureFromSurface( gRenderer, loadedSurface );
		if( newTexture == NULL )
		{
			printf( "Unable to create texture from %s! SDL Error: %s\n", path.c_str(), SDL_GetError() );
		}

		//Get rid of old loaded surface
		SDL_FreeSurface( loadedSurface );
	}

	return newTexture;
}

int main( int argc, char* args[] )
{
	//Start up SDL and create window
	if( !init() )
	{
		printf( "Failed to initialize!\n" );
	}
	else
	{
		//Load media
		if( !loadMedia() )
		{
			printf( "Failed to load media!\n" );
		}
		else
		{
			//Main loop flag
			bool quit = false;

			//Event handler
			SDL_Event e;
            SDL_Rect camera = { 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT };
			float cVelX = 0.2;
			Queue objectList(0.4);
            Queue bg(0.2);
            Queue clouds(0.2);
			int z=0;
            int fr=0;
            int a=400;
			bool pressed=false;
			int Count=0;
			int b=0;
			int c=0;
			int d=450;
			Unit* r;
			for (int i=0;i<25;i++)
            {
                r=new Unit(&road1,srcRect[7],c,d);
                objectList.Enqueue(r);
                c+=srcRect[7].w;
            }
            int l = 300;
            for(int i=0;i<10;i++)
            {
                int m = rand()%3;
                if (m==0)
                    r=new Unit(&building1,build[m],l,280);
                else if (m==1)
                    r=new Unit(&building1,build[m],l,320);
                else
                    r=new Unit(&building1,build[m],l,325);
                bg.Enqueue(r);
                l+=1500;
            }

            Unit* t = new Unit(&tomb,renderquad[0],2700,125);
            bg.Enqueue(t);

            Unit* p = new Unit(&chaarMinar,renderquad[1],4000,15);
            bg.Enqueue(p);

            Unit* h = new Unit(&hbl,renderquad[2],5500,0);
            bg.Enqueue(h);

            Unit* al = new Unit(&altafHussain,renderquad[3],6600,-20);
            bg.Enqueue(al);

            Unit* teen = new Unit(&teentalwar,renderquad[4],1000,130);
            bg.Enqueue(teen);
			//While application is running
			Player player;
			Enemy enemy;

			//Unit* v = new Vehicle(&vtexture,veh[1],600,330);

			Unit* cl;

            for (int i=500;i<6500;i=i+600)
            {
                cl=new Unit(&c2texture,cloud2,i,20);
                clouds.Enqueue(cl);
            }
			while( !quit )
			{
			    if((fr%3 == 0) & (Count<25))
                {
			        int random = rand() % 5;
			        if ((random==1) || (random==6))
                        b=470;
                    else if ((random==0) || (random==5))
                        b=460;
                    else if ((random==3) || (random==2))
                        b=380;
                    else if (random==4)
                        b=430;

                    Unit* u = new Obstacle(&ggTexture,srcRect[random],a,b);
                    //cout<<a<<endl;
                    if ((random==1) || (random==6))
                        a+=400;
                    else if ((random==0) || (random==5))
                        a+=400;
                    else if ((random==3) || (random==2) || (random==4))
                        a+=600;

                   objectList.Enqueue(u);
                    Count++;

                    if ((a>2500) & (a<3500))
                        a+=1000;
                }

				//Handle events on queue
				while( SDL_PollEvent( &e ) != 0 )
				{
					//User requests quit
					if( e.type == SDL_QUIT )
					{
						quit = true;
					}
					else if( e.type == SDL_KEYDOWN && e.key.repeat == 0 )
                    {
//                        pressed=true;
                    //Adjust the velocity
                        switch( e.key.keysym.sym )
                        {
                            case SDLK_LEFT:
                                pressed=true;
                                cVelX-=0.5;
                                z=2;
                                break;
                            case SDLK_RIGHT:
                                pressed=true;
                                cVelX+=0.5;
                                z=-2;
                                break;
                        }
                    }

                    else if( e.type == SDL_KEYUP && e.key.repeat == 0 )
                    {
                    //Adjust the velocity
                        switch( e.key.keysym.sym )
                        {
                            case SDLK_LEFT:
                                pressed=false;
                                cVelX+=0.5;
                                z=2;
                                break;
                            case SDLK_RIGHT:
                                pressed=false;
                                cVelX-=0.5;
                                z=-2;
                                break;
                        }
                    }
                    player.handleEvent( e );
					player.isJump(e);
				}

				if ((player.checkJump == true) & (player.mPosY > base - 200))
                {
                    player.jump();
                    if (player.mPosY == base - 200)
                    {
                        player.checkJump = false;
                    }
                }

                else if ((player.checkJump == false) & (player.mPosY < base))
                {
                    player.fall();
                }

                else
                {
                    player.move();
                }
                enemy.move();
				int w,h;
				SDL_QueryTexture(gTexture,NULL,NULL,&w,&h);

                if ((pressed==true) & (z==-2))// & (camera.x < w - camera.w) & (camera.x >0))
                {   camera.x += cVelX;
                    objectList.MoveRight();
                    bg.MoveRight();
                    clouds.MoveRight();
//                    v->Move();

                }
                else if ((pressed==true) & (z==-2))// & (camera.x < w - camera.w) & (camera.x >0))
                {   camera.x += cVelX;
                    objectList.MoveLeft();
                    bg.MoveLeft();
//                    v->Move();

                }
                    //objectList.Move(z);
                //    v->Move(z);
                    //q->Move(z);
                if( camera.x < 0 )
				{
					camera.x = 0;
					//objectList.Move(-z);
				}

				if( camera.y < 0 )
				{
					camera.y = 0;
				}

				if(camera.x > w - camera.w)
                {
                    camera.x = w - camera.w;

                }
				if( camera.y > LEVEL_HEIGHT - camera.h )
				{
					camera.y = LEVEL_HEIGHT - camera.h;
				}

				/*if ((player.mPosX>v->GetX()) && (player.mPosX<v->GetX()+v->GetWidth()))
				{
//				    v->Move(0.5);
				    player.move();

				}*/


                //SDL_RenderPresent( gRenderer );
				//Clear screen
				SDL_RenderClear( gRenderer );

                //Render texture to screen
				SDL_RenderCopy( gRenderer, gTexture, &camera,NULL );
                clouds.Render(gRenderer);
                bg.Render(gRenderer);
                objectList.Render(gRenderer);
                objectList.Clean();
                //SDL_Delay(1);
                bg.Clean();
				//Update screen
				//gSpriteSheetTexture.Render(100,100, &srcRect[8], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
//                v->Render(gRenderer);
				if (player.checkRun(e) == true)
                {
                    player.runRender();
                    countt++;
                }

                else
                {
                    player.standRender();
                }

                if (countt == 10)
                {
                    ++frame;
                    countt = 0;
                }
                enemy.runRender();
                countt1++;
                if (countt1 == 10)
                {
                    ++frame1;
                    countt1 = 0;
                }

               // cout<<bg.GetLength()<<endl;
               // cout<<objectList.GetLength()<<endl;

				SDL_RenderPresent( gRenderer );
				fr++;
				if( frame / 6 >= WALKING_ANIMATION_FRAMES )
				{
					frame = 0;
				}
				if( frame1 / 6 >= WALKING_ANIMATION_FRAMES )
				{
					frame1 = 0;
				}
			}
		}
	}

	//Free resources and close SDL
	close();

	return 0;
}
