#include "Vehicle.h"


Vehicle::Vehicle()
{

}

Vehicle::~Vehicle()
{
    cout<<"Obstacle Deallocated"<<endl;
    //spriteSheetTexture = NULL;
}

Vehicle::Vehicle(LTexture* image, SDL_Rect r, float x, float y):Unit(image,r,x,y)
{
    this->x=x;
    this->y=y;
    spriteSheetTexture = image;
    src=r;
    //friction = 0.95f;
    //speedx = 0;
    //speedy = 0;
    alive = true;
}


void Vehicle::Move()
{
    if ( x < -400)
        SetAlive(false);
}


void Vehicle::Move(int d)
{
    x=x+d;
}
void Vehicle::Render(SDL_Renderer* gRenderer)
{
  //  cout<"K";
    spriteSheetTexture->Render( x, y, &src, 0.0, NULL, SDL_FLIP_NONE, gRenderer );
}

