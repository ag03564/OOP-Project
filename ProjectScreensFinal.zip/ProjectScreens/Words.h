#pragma once
#include "SDL.h"
#include "SDL_image.h"
#include "iostream"
#include "string"
#include "Words.h"
#include "LTexture.h"
#include "Characters.h"
#include "CharacterBig.h"
using namespace std;

class Word
{
private:
    int x_pos, y_pos;
    string renderWord;
    LTexture* charTexture;
    Character* characters; ///for normal words
    CharacterBig* characs; ///for bigger words
public:
    Word(string str ,LTexture* gSpriteSheetTexture, int x, int y);
    Word(string str ,LTexture* gSpriteSheetTexture, int x, int y,long int& frame);
    void render(SDL_Renderer* gRenderer);
    void renderbig(SDL_Renderer* gRenderer);
    void setText(string str);
    void setTextBig(string str);
    int getTextLength();

};
