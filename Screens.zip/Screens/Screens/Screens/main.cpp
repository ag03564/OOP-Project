//Using SDL, SDL_image, standard math, and strings
#include <SDL.h>
#include <SDL_image.h>
#include <SDL_mixer.h>
#include <stdio.h>
#include <string>
#include <time.h>
#include <cstdlib>
#include <string>
#include "iostream"
#include "Buttons.h"
#include "menuScreen.h"
#include "Screen.h"
#include "LTexture.h"
#include "Words.h"
#include "gamescreen.h"
#include "pausescreen.h"
#include "gameover.h"
#include "Unit.h"
#include "Queue.h"
#include "Obstacle.h"
#include "Vehicle.h"
#include "Player.h"
#include "Enemy.h"

using namespace std;

SDL_Window* gWindow = NULL;
SDL_Renderer* gRenderer = NULL;
SDL_Surface* gScreenSurface = NULL;
SDL_Surface* gBackgroundSurface = NULL;

Mix_Music *gMusic = NULL;
Mix_Chunk *gMedium = NULL;

SDL_Surface* loadSurface( std::string path );
SDL_Texture* addBackground();

LTexture Background;
LTexture ButtonTextureSheet;
LTexture FontTextureSheet;
LTexture GameTextureSheet;
LTexture PauseTextureSheet;


SDL_Rect ButtonTextureClip;
SDL_Rect Backgroundclip;
SDL_Rect Admiclip;



//for Gameplay
SDL_Rect srcRect[8];
SDL_Rect build[9];
SDL_Rect cloud,cloud2;
SDL_Rect renderquad[5];
SDL_Rect vehicle_sprite[3];
LTexture ggTexture;
LTexture ctexture,c2texture;
LTexture sit_rickshaw, sit_bike;
SDL_Texture* gTexture = NULL;

LTexture road1;
LTexture building1;
LTexture teentalwar;
LTexture hbl;
LTexture chaarMinar;
LTexture tomb;
LTexture altafHussain;

LTexture vtexture;
SDL_Rect veh[3];
const int jumpHeight = 10;
LTexture gSpriteSheetTexture;
LTexture gSpriteSheetTexture1;
static const int WALKING_ANIMATION_FRAMES = 6;
SDL_Rect gSpriteClips[ WALKING_ANIMATION_FRAMES ];
SDL_Rect gSpriteClips1[ WALKING_ANIMATION_FRAMES ];
int frame = 0;
int frame1 = 0;
int base = 435;
int countt=0;
int countt1=0;
const int LEVEL_WIDTH = 7000;
const int LEVEL_HEIGHT = 700;

const int SCREEN_WIDTH = 800;
const int SCREEN_HEIGHT = 600;


bool init()
{
	//Initialization flag
	bool success = true;

	//Initialize SDL
    if( SDL_Init( SDL_INIT_VIDEO ) < 0 )
    {
        printf( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
        success = false;
    }
	else
	{
		//Set texture filtering to linear
		if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) )
		{
			printf( "Warning: Linear texture filtering not enabled!" );
		}

		//Create window
		gWindow = SDL_CreateWindow( "SDL Tutorial", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH-30, SCREEN_HEIGHT-10, SDL_WINDOW_SHOWN );
		if( gWindow == NULL )
		{
			printf( "Window could not be created! SDL Error: %s\n", SDL_GetError() );
			success = false;
		}
		else
		{
			//Create renderer for window
			gRenderer = SDL_CreateRenderer( gWindow, -1, SDL_RENDERER_ACCELERATED );
			if( gRenderer == NULL )
			{
				printf( "Renderer could not be created! SDL Error: %s\n", SDL_GetError() );
				success = false;
			}
			else
			{
				//Initialize renderer color
				SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );

				//Initialize PNG loading
				int imgFlags = IMG_INIT_PNG;
				if( !( IMG_Init( imgFlags ) & imgFlags ) )
				{
					printf( "SDL_image could not initialize! SDL_mage Error: %s\n", IMG_GetError() );
					success = false;
				}

                if( Mix_OpenAudio( 44100, MIX_DEFAULT_FORMAT, 2, 2048 ) < 0 )
                {
                    printf( "SDL_mixer could not initialize! SDL_mixer Error: %s\n", Mix_GetError() );
                    success = false;
                }

                //Get window surface
                gScreenSurface = SDL_GetWindowSurface( gWindow );


			}
		}
	}

	return success;
}

SDL_Texture* loadTexture( std::string path )
{
    //The final texture
    SDL_Texture* newTexture = NULL;

    //Load image at specified path
    SDL_Surface* loadedSurface = IMG_Load( path.c_str() );
    if( loadedSurface == NULL )
    {
        printf( "Unable to load image %s! SDL_image Error: %s\n", path.c_str(), IMG_GetError() );
    }
    else
    {
        //Create texture from surface pixels
        newTexture = SDL_CreateTextureFromSurface( gRenderer, loadedSurface );
        if( newTexture == NULL )
        {
            printf( "Unable to create texture from %s! SDL Error: %s\n", path.c_str(), SDL_GetError() );
        }

        //Get rid of old loaded surface
        SDL_FreeSurface( loadedSurface );
    }

    return newTexture;
}


bool loadMedia()
{
    bool success = true;
	if( !Background.LoadFromFile( "Background2.png", gRenderer) )
	{
		printf( "Failed to Background sheet texture!\n" );
		success = false;
	}

	if( !FontTextureSheet.LoadFromFile( "XiroidFinal2.png", gRenderer) )
	{
		printf( "Failed to load sprite sheet texture!\n" );
		success = false;
	}

    if( !ButtonTextureSheet.LoadFromFile( "XiroidFinal2.png", gRenderer) )
	{
		printf( "Failed to load sprite sheet texture!\n" );
		success = false;
	}

    if( !GameTextureSheet.LoadFromFile( "newgame.png", gRenderer) )
	{
		printf( "Failed to game sprite sheet texture!\n" );
		success = false;
	}

    if( !PauseTextureSheet.LoadFromFile( "pausebg.png", gRenderer) )
	{
		printf( "Failed to pause sprite sheet texture!\n" );
		success = false;
	}

    gMusic = Mix_LoadMUS( "Lounge Game.wav" );

    if( gMusic == NULL )
    {
        printf( "Failed to load beat music! SDL_mixer Error: %s\n", Mix_GetError() );
        success = false;
    }

	gMedium = Mix_LoadWAV( "medium.wav" );
	if( gMedium == NULL )
	{
		printf( "Failed to load medium sound effect! SDL_mixer Error: %s\n", Mix_GetError() );
		success = false;
	}
	gTexture = loadTexture( "New Project.jpg" );
    if( gTexture == NULL )
    {
        printf( "Failed to load texture image!\n" );
        success = false;
    }

    if (!ggTexture.LoadFromFile("imageedit_4_2597540840.png",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }

    //gameplay








    else
    {
        srcRect[0].x = 409;
        srcRect[0].y = 375;
        srcRect[0].w = 110;
        srcRect[0].h = 75;

        srcRect[1].x = 552;
        srcRect[1].y = 385;
        srcRect[1].w = 88;
        srcRect[1].h = 63;

        srcRect[2].x = 427;
        srcRect[2].y = 3;
        srcRect[2].w = 213;
        srcRect[2].h = 165;

        srcRect[3].x = 0;
        srcRect[3].y = 146;
        srcRect[3].w = 395;
        srcRect[3].h = 196;

        srcRect[4].x = 412;
        srcRect[4].y = 176;
        srcRect[4].w = 228;
        srcRect[4].h = 112;

        srcRect[5].x = 409;
        srcRect[5].y = 375;
        srcRect[5].w = 110;
        srcRect[5].h = 75;

        srcRect[6].x = 552;
        srcRect[6].y = 385;
        srcRect[6].w = 88;
        srcRect[6].h = 63;
    }

    if (!road1.LoadFromFile("road.jpeg",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
    else
    {
        srcRect[7].x=30;
        srcRect[7].y=0;
        srcRect[7].w=900;
        srcRect[7].h=230;
    }
    if (!building1.LoadFromFile("buildings.png",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
    else
    {
        build[0].x = 0;
        build[0].y = 35;
        build[0].w = 564;
        build[0].h = 188;

        build[1].x = 27;
        build[1].y = 261;
        build[1].w = 570;
        build[1].h = 136;

        build[2].x = 40;
        build[2].y = 460;
        build[2].w = 556;
        build[2].h = 131;

        build[3].x = 0;
        build[3].y = 200;
        build[3].w = 200;
        build[3].h = 200;

        build[4].x = 200;
        build[4].y = 200;
        build[4].w = 200;
        build[4].h = 200;

        build[5].x = 400;
        build[5].y = 200;
        build[5].w = 200;
        build[5].h = 200;

        build[6].x = 0;
        build[6].y = 400;
        build[6].w = 88;
        build[6].h = 63;

        build[7].x = 200;
        build[7].y = 400;
        build[7].w = 200;
        build[7].h = 200;

        build[8].x = 400;
        build[8].y = 400;
        build[8].w = 200;
        build[8].h = 200;

    }
    if (!tomb.LoadFromFile("tomb.png",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
    else
    {
        renderquad[0] = {0,0,tomb.GetWidth(),tomb.GetHeight()};
    }
    if (!chaarMinar.LoadFromFile("chaarminar.png",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
    else
    {
        renderquad[1] = {0,0,chaarMinar.GetWidth(),chaarMinar.GetHeight()};
    }
    if (!hbl.LoadFromFile("hbl.png",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
    else
    {
        renderquad[2] = {0,0,hbl.GetWidth(),450};
    }

    if (!altafHussain.LoadFromFile("bhai.gif",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
    else
    {
        renderquad[3] = {0,0,altafHussain.GetWidth(),altafHussain.GetHeight()};
    }

    if (!teentalwar.LoadFromFile("teentalwar.png",gRenderer))
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
    else
    {
        renderquad[4] = {0,0,teentalwar.GetWidth(),teentalwar.GetHeight()};
    }

    if( !gSpriteSheetTexture.LoadFromFile( "running.png",gRenderer) )
    {
        printf( "Failed to load dot texture!\n" );
        success = false;
    }
    else
    {
        gSpriteClips[ 0 ].x =   33;
        gSpriteClips[ 0 ].y =   12;
        gSpriteClips[ 0 ].w =   62;
        gSpriteClips[ 0 ].h =   100;

        gSpriteClips[ 1 ].x =  95;
        gSpriteClips[ 1 ].y =  12;
        gSpriteClips[ 1 ].w =  62;
        gSpriteClips[ 1 ].h =  100;

        gSpriteClips[ 2 ].x = 157;
        gSpriteClips[ 2 ].y = 12;
        gSpriteClips[ 2 ].w = 62;
        gSpriteClips[ 2 ].h = 100;

        gSpriteClips[ 3 ].x = 30;
        gSpriteClips[ 3 ].y = 120;
        gSpriteClips[ 3 ].w = 62;
        gSpriteClips[ 3 ].h = 100;

        gSpriteClips[ 4 ].x = 92;
        gSpriteClips[ 4 ].y = 120;
        gSpriteClips[ 4 ].w = 62;
        gSpriteClips[ 4 ].h = 100;

        gSpriteClips[ 5 ].x = 154;
        gSpriteClips[ 5 ].y = 120;
        gSpriteClips[ 5 ].w = 62;
        gSpriteClips[ 5 ].h = 100;
    }

    if(!vtexture.LoadFromFile("Vehicle_3.png",gRenderer))
    {
        printf( "Failed to load dot texture!\n" );
        success = false;
    }
    else
    {
        veh[1].x= 20;
        veh[1].y= 160;
        veh[1].w= 228;
        veh[1].h= 120;

        veh[2].x= 280;
        veh[2].y= 170;
        veh[2].w= 200;
        veh[2].h= 115;

    }

    if(!c2texture.LoadFromFile("10-cloud-png-image-thumb.png",gRenderer))
    {
        printf( "Failed to load dot texture!\n" );
        success = false;
    }
    else
    {
        cloud2.x=0;
        cloud2.y=0;
        cloud2.w=c2texture.GetWidth();
        cloud2.h=c2texture.GetHeight();
    }

    if(!sit_bike.LoadFromFile("Vehicle_final6.png",gRenderer))
    {
        printf( "Failed to load dot texture!\n" );
        success = false;
    }
    else
    {
        vehicle_sprite[1].x=11;
        vehicle_sprite[1].y=356;
        vehicle_sprite[1].w=228;
        vehicle_sprite[1].h=112;

        vehicle_sprite[2].x=239;
        vehicle_sprite[2].y=362;
        vehicle_sprite[2].w=200;
        vehicle_sprite[2].h=115;
    }

	return success;
}

void close()
{

	//Destroy window
	Background.Free();
    FontTextureSheet.Free();
    ButtonTextureSheet.Free();

	Mix_FreeChunk( gMedium );
	gMedium = NULL;
    Mix_FreeMusic( gMusic );
    gMusic = NULL;

	SDL_DestroyRenderer( gRenderer );
	SDL_DestroyWindow( gWindow );
	gWindow = NULL;
	gRenderer = NULL;


	//Quit SDL subsystems
	IMG_Quit();
	SDL_Quit();
}

bool checkCollision( SDL_Rect a, SDL_Rect b )
{
    //The sides of the rectangles
    int leftA, leftB;
    int rightA, rightB;
    int topA, topB;
    int bottomA, bottomB;
    //Calculate the sides of rect A
    leftA = a.x;
    rightA = a.x + a.w;
    topA = a.y;
    bottomA = a.y+ a.h;

    //Calculate the sides of rect B
    leftB = b.x;
    rightB = b.x + b.w;
    topB = b.y;
    bottomB = b.y + b.h;
//    cout<<topA<<endl;
//    cout<<topB<<endl;
//    If any of the sides from A are outside of B
    if( bottomA <= topB )
    {
        return false;
    }

    if( topA >= bottomB )
    {
        return false;
    }

    if( rightA <= leftB )
    {
        return false;
    }

    if( leftA >= rightB )
    {
        return false;
    }

    //If none of the sides from A are outside B
    return true;
}




SDL_Surface* loadSurface( std::string path )
{
	//The final optimized image
	SDL_Surface* optimizedSurface = NULL;

	//Load image at specified path
	SDL_Surface* loadedSurface = IMG_Load( path.c_str() );
	if( loadedSurface == NULL )
	{
		printf( "Unable to load image %s! SDL_image Error: %s\n", path.c_str(), IMG_GetError() );
	}
	else
	{
		//Convert surface to screen format
		optimizedSurface = SDL_ConvertSurface( loadedSurface, gScreenSurface->format, NULL );
		if( optimizedSurface == NULL )
		{
			printf( "Unable to optimize image %s! SDL Error: %s\n", path.c_str(), SDL_GetError() );
		}

		//Get rid of old loaded surface
		SDL_FreeSurface( loadedSurface );
	}

	return optimizedSurface;
}


int main( int argc, char* args[] )
{	//Start up SDL and create window
	if( !init() )
	{
		printf( "Failed to initialize!\n" );
	}
	else
	{

		if( !loadMedia() )
		{
			printf( "Failed to load media!\n" );
		}
		else
		{

            long int frame = 0;
            bool mouseClicked=false;
			bool menusc=true;
			bool gamesc=false;
			bool loadsc=false;
			bool pausesc=false;
			bool gameover=false;
			bool quit = false;
			SDL_Event e;
            Word go("GAME OVER!!",&FontTextureSheet,SCREEN_WIDTH/2-270,SCREEN_HEIGHT/2-150,frame);

            menuScreen menu(&Background,&FontTextureSheet,&FontTextureSheet);
            GameScreen gamestart(&GameTextureSheet,&FontTextureSheet,&FontTextureSheet);
            pauseScreen pause(&PauseTextureSheet,&FontTextureSheet,&FontTextureSheet);
            gameoverScreen gamefin(&Background,&FontTextureSheet,&FontTextureSheet);
            SDL_Texture* bgTexture = SDL_CreateTextureFromSurface(gRenderer, gScreenSurface);

//			Button btnstart("START", &FontTextureSheet, &ButtonTextureSheet, ButtonTextureClip, SCREEN_WIDTH/2+200, SCREEN_HEIGHT/2-150, 300, 60);
//			Button btnstart1("START", &FontTextureSheet, &ButtonTextureSheet, ButtonTextureClip, SCREEN_WIDTH/2+200, SCREEN_HEIGHT/2-150, 300, 60);

            //While application is running`
			while( !quit )
			{
				//Handle events on queue
				while( SDL_PollEvent( &e ) != 0 )
				{
					//User requests quit
					if( e.type == SDL_QUIT )
					{
						quit = true;
					}
				//Clear screen
				SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );
				SDL_RenderClear( gRenderer );
				if (menusc)
                {
                    menu.Render(frame,gRenderer);
                    menu.mouseMotionEvents(&e,gRenderer);
                    if( Mix_PlayingMusic() == 0 )
                    {
                        Mix_PlayMusic( gMusic, -1 );
                    }

                    if (menu.getButtons()[0].getstate()==2)///when start game clicked
                    {

                        Mix_PlayChannel( -1, gMedium, 0 );
                        Mix_HaltMusic();
                        menusc=false;
                        gamesc=true;

                                    //Event handler
            SDL_Event e;
            SDL_Rect camera = { 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT };
            float cVelX = 0.2;
            Queue objectList(0.4);
            Queue bg(0.2);
            Queue clouds(0.2);
            int z=0;
            int fr=0;
            int a=300;
            int Count=0;
            int b=0;
            int c=0;
            int d=450;
            int rick=0;
            int bike=0;
            bool pressed=false;
            bool success=false;
            bool found=false;
            bool found2=false;
            bool has_rickshaw=false;
            bool has_bike=false;
            bool healthcheck = false;
            bool stop=false;
            bool vehicle_stop=false;
            Unit* r;

            for (int i=0; i<35; i++)
            {
                r=new Unit(&road1,srcRect[7],c,d);
                objectList.Enqueue(r);
                c+=srcRect[7].w;
            }

            int l = 300;
            for(int i=0; i<15; i++)
            {
                int m = rand()%3;
                if (m==0)
                    r=new Unit(&building1,build[m],l,280);
                else if (m==1)
                    r=new Unit(&building1,build[m],l,320);
                else
                    r=new Unit(&building1,build[m],l,325);
                bg.Enqueue(r);
                l+=1500;
            }

            Unit* t = new Unit(&tomb,renderquad[0],2700,125);
            bg.Enqueue(t);

            Unit* p = new Unit(&chaarMinar,renderquad[1],4000,15);
            bg.Enqueue(p);

            Unit* h = new Unit(&hbl,renderquad[2],5500,0);
            bg.Enqueue(h);

            Unit* al = new Unit(&altafHussain,renderquad[3],6600,-20);
            bg.Enqueue(al);

            Unit* teen = new Unit(&teentalwar,renderquad[4],1000,130);
            bg.Enqueue(teen);
            //While application is running
            Player player(&gSpriteSheetTexture);
            Enemy enemy(&gSpriteSheetTexture);

            bool spike=false;
            bool box=false;
            bool log=false;

            Vehicle* v1 = new Vehicle(&vtexture,veh[1],2500,400);
            Vehicle* v2 = new Vehicle(&vtexture,veh[2],4000,400);

            Unit* cl;

            for (int i=500; i<10000; i=i+600)
            {
                cl=new Unit(&c2texture,cloud2,i,20);
                clouds.Enqueue(cl);
            }

            int marking = 0;
            Obstacle * u[60];
            for(int i=0; i<60; i++)
            {
                int random = rand() % 5;
                if ((random==1) || (random==6))
                {
                    b=470;
                    marking=1;
                }
                else if ((random==0) || (random==5))
                {
                    b=460;
                    marking=1;
                }
                else if ((random==3) || (random==2))
                {
                    b=380;
                    marking=3;
                }
                else if (random==4)
                {
                    b=430;
                    marking=4;
                }

                u[i] = new Obstacle(&ggTexture,srcRect[random],a,b,marking);
                //cout<<a<<endl;
                if ((random==1) || (random==6))
                    a+=400;
                else if ((random==0) || (random==5))
                    a+=400;
                else if ((random==3) || (random==2) || (random==4))
                    a+=800;

                if (((a>2300) & (a<2800)) || ((a>3800) & (a<4500)))
                    a+=700;
            }

            while( !quit )
            {
                //Handle events on queue
                while( SDL_PollEvent( &e ) != 0 )
                {
                    //User requests quit
                    if( e.type == SDL_QUIT )
                    {
                        quit = true;
                    }
                    else if( e.type == SDL_KEYDOWN && e.key.repeat == 0 )
                    {
//                        pressed=true;
                        //Adjust the velocity
                        switch( e.key.keysym.sym )
                        {
                        case SDLK_LEFT:
                            pressed=true;
                            cVelX-=0.5;
                            z=2;
                            break;
                        case SDLK_RIGHT:
                            pressed=true;
                            cVelX+=0.5;
                            z=-2;
                            break;
                        }
                    }

                    else if( e.type == SDL_KEYUP && e.key.repeat == 0 )
                    {
                        //Adjust the velocity
                        switch( e.key.keysym.sym )
                        {
                        case SDLK_LEFT:
                            pressed=false;
                            cVelX+=0.5;
                            z=2;
                            break;
                        case SDLK_RIGHT:
                            pressed=false;
                            cVelX-=0.5;
                            z=-2;
                            break;
                        }
                    }
                    player.handleEvent( e );
                    player.isJump(e);
                }
                //success=false;

                for (int i=0; i<60; i++)
                {
                    if (u[i]!=NULL)
                    {
                        if (checkCollision(player.mCollider,u[i]->coll))
                        {
                            if (u[i]->mark==1)
                                spike=true;
                            else if (u[i]->mark==3)
                                box=true;
                            else if (u[i]->mark==4)
                                log=true;
                            success=true;
                            break;
                        }
                        else
                        {
                            spike=false;
                            box=false;
                            log=false;
                            success=false;
                        }
                    }
                }

                for (int i=0; i<60; i++)
                {
                    if (u[i]!=NULL)
                    {
                        if (checkCollision(enemy.mCollider,u[i]->coll))
                        {
                            stop=true;
                            break;
                        }
                        else
                        {
                            stop=false;
                        }
                    }
                }


                for (int i=0; i<60; i++)
                {
                    if ((u[i]!=NULL) & (v1!=NULL))
                    {

                        if (checkCollision(v1->vv,u[i]->coll))
                        {
                            if (u[i]->mark!=1)
                            {
                                vehicle_stop=true;
                                break;
                            }
                        }
                        else
                        {
                            vehicle_stop=false;
                        }
                    }
                }

                if (v1!=NULL)
                {
                    if (checkCollision(player.mCollider,v1->vv))
                    {
                        v1->Move(player.mPosX+1);
                        has_bike=true;
                        if (found==false)
                        {
                            bike=fr;
                            found=true;
                        }
                    }
                }

                if (v2!=NULL)
                {
                    if (checkCollision(player.mCollider,v2->vv))
                    {
                        v2->Move(player.mPosX);
                        has_rickshaw=true;
                        if (found2==false)
                        {
                            rick=fr;
                            found2=true;
                        }

                    }
                }

                if ((spike == true) & (fr%300==0))
                {
                    player.loseHealth();
                    cout<<player.health << endl;
                }

                if ((checkCollision(player.mCollider,enemy.mCollider)) & (fr!=0))
                {
                    player.health=0;
                    cout<<"Player dead";
                }

                if ((player.checkJump == true) & (player.mPosY > base - 200))
                {
                    if (!has_rickshaw)
                    {
                        player.jump();
                        success=false;
                        if (player.mPosY == base - 200)
                        {
                            player.checkJump = false;
                        }
                    }
                }

                else if ((player.checkJump == false) & (player.mPosY < base))
                {
                    if (((box==true) & (player.mPosY<=360)) || ((log==true) & (player.mPosY<=415)))
                    {
                        //player.move();
                    }
                    else
                    {
                        player.fall();
                    }
                }

                else if ((success==false) || ((box) & (player.mPosY<=360)))
                {
                    if ((vehicle_stop==true) & (has_bike))
                    {

                    }
                    else
                    {
                        player.move();
                    }

                }

                if ((stop==true)&(enemy.mPosY > base - 200))
                {
                    enemy.jump();
                    if (enemy.mPosY == base - 200)
                        stop=false;
                }

                else if ((stop==false)&(enemy.mPosY < base))
                {
                    enemy.fall();
                }

                enemy.move();

                int w,h;
                SDL_QueryTexture(gTexture,NULL,NULL,&w,&h);

                if ((pressed==true) &  (z==-2) & ((success==false) || (spike==true))) // & (camera.x < w - camera.w) & (camera.x >0))
                {
                    if ((has_bike) & (vehicle_stop) & (!spike))
                    {
                    }
                    else
                    {
                        camera.x += cVelX;
                        objectList.MoveRight();
                        bg.MoveRight();
                        clouds.MoveRight();
                        if (v1!=NULL)
                            v1->Move();
                        if (v2!=NULL)
                            v2->Move();
                        for (int i=0; i<60; i++)
                        {
                            if (u[i]!=NULL)
                            {
                                u[i]->Move(1);
                            }
                        }
                    }

                }
                else if ((success==true) & (has_rickshaw)) // & (camera.x < w - camera.w) & (camera.x >0))
                {
                    camera.x += cVelX;
                    objectList.MoveRight();
                    bg.MoveRight();
                    clouds.MoveRight();
                    if (v1!=NULL)
                        v1->Move();

                    for (int i=0; i<60; i++)
                    {
                        if (u[i]!=NULL)
                        {
                            u[i]->Move(1);
                        }
                    }

                }

                else if (((success==true) & (box==true) & (player.mPosY<=360)) || ((success==true) & (log==true) & (player.mPosY<=415))) // & (camera.x < w - camera.w) & (camera.x >0))
                {
                    camera.x += cVelX;
                    objectList.MoveRight();
                    bg.MoveRight();
                    clouds.MoveRight();
                    if (v1!=NULL)
                        v1->Move();
//                    if (v2!=NULL)
//                        v2->Move();
                    for (int i=0; i<60; i++)
                    {

                        if (u[i]!=NULL)
                        {
                            u[i]->Move(1);
                        }
                    }
                }

               camera.x = ( player.mPosX + Player::PLAYER_WIDTH / 2 ) - SCREEN_WIDTH / 2;
                camera.y = ( player.mPosY + Player::PLAYER_HEIGHT / 2 ) - SCREEN_HEIGHT / 2;

                if( camera.x < 0 )
                {
                    camera.x = 0;
                    //objectList.Move(-z);
                }

                if( camera.y < 0 )
                {
                    camera.y = 0;
                }

                if(camera.x > w - camera.w)
                {
                    camera.x = w - camera.w;

                }
//                if( camera.y > LEVEL_HEIGHT - camera.h )
//                {
//                    camera.y = LEVEL_HEIGHT - camera.h;
//                }


                SDL_RenderClear( gRenderer );

                SDL_RenderCopy( gRenderer, gTexture, &camera,NULL );
                clouds.Render(gRenderer);
                bg.Render(gRenderer);
                objectList.Render(gRenderer);
                for (int i=0; i<60; i++)
                {
                    if (u[i]!=NULL)
                    {
                        u[i]->Move();
                        u[i]->Render(gRenderer);
                    }
                }
                objectList.Clean();
                //SDL_Delay(1);
                bg.Clean();


                if (v2!=NULL)
                {
                    if (!has_rickshaw)
                        v2->Render(gRenderer);
                }

                if (v1!=NULL)
                {
                    if (!has_bike)
                        v1->Render(gRenderer);
                }

                if (player.checkRun(e) == true)
                {
                    if (has_bike)
                    {
                        sit_bike.Render(player.mPosX,player.mPosY,&vehicle_sprite[1],0.0, NULL, SDL_FLIP_NONE, gRenderer);
                    }
                    else if (has_rickshaw)
                    {
                        sit_bike.Render(player.mPosX,player.mPosY,&vehicle_sprite[2],0.0, NULL, SDL_FLIP_NONE, gRenderer);
                    }
                    else
                    {
                        SDL_Rect* currentClip = &gSpriteClips[ frame / 6 ];
                        player.runRender(camera.x,*currentClip,gRenderer);
                    }
                    countt++;
                }

                else
                {
                    if (has_bike)
                    {
                        sit_bike.Render(player.mPosX,player.mPosY,&vehicle_sprite[1],0.0, NULL, SDL_FLIP_NONE, gRenderer);
                    }
                    else if (has_rickshaw)
                    {
                        sit_bike.Render(player.mPosX,player.mPosY,&vehicle_sprite[2],0.0, NULL, SDL_FLIP_NONE, gRenderer);
                    }
                    else
                    {
                        SDL_Rect* currentClip = &gSpriteClips[5];
                        player.standRender(camera.x,*currentClip,gRenderer);
                    }
                }

                if (countt == 10)
                {
                    ++frame;
                    countt = 0;
                }
                SDL_Rect* currentClip = &gSpriteClips[ frame / 6 ];
                enemy.runRender(camera.x,*currentClip,gRenderer);
                countt1++;
                if (countt1 == 10)
                {
                    ++frame1;
                    countt1 = 0;
                }


                SDL_RenderPresent( gRenderer );
                fr++;
                if( frame / 6 >= WALKING_ANIMATION_FRAMES )
                {
                    frame = 0;
                }
                if( frame1 / 6 >= WALKING_ANIMATION_FRAMES )
                {
                    frame1 = 0;
                }
                if ((fr>bike+1500)  & (has_bike) & (bike!=0))
                {
                    has_bike=false;
                    delete v1;
                    v1=NULL;
                }
                if ((fr>rick+1500) & (has_rickshaw) & (rick!=0))
                {
                    has_rickshaw=false;
                    delete v2;
                    v2=NULL;
                }

                for (int i=0; i<60; i++)
                {
                    if (u[i]!=NULL)
                    {
                        if (!u[i]->GetAlive())
                        {
                            delete u[i];
                            u[i]=NULL;
                        }
                    }
                }
                player.mPosX=player.mPosX-camera.x;
                enemy.mPosX=enemy.mPosX-camera.x;
                    }
                }
                    if (menu.getButtons()[1].getstate()==2) ///when load game clicked
                    {
                        Mix_PlayChannel( -1, gMedium, 0 );
                        loadsc=true;
                        menusc=false;
                    }


                    if (menu.getButtons()[2].getstate()==2) ///when quit is pressed
                    {

                        Mix_PlayChannel( -1, gMedium, 0 );
                        quit=true;
                        cout<<"menu exit"<<endl;
                    }

                }
                if (gamesc) ///gamescreen running
                {
                    gamestart.Render(frame,gRenderer);
                    gamestart.mouseMotionEvents(&e,gRenderer);

                    cout<<"Game screen entered"<<endl;
                    if (gamestart.getButtons()[0].getstate()==2) ///resume button pressed
                    {
                        Mix_PlayChannel( -1, gMedium, 0 );

                        gamesc=false;
                        pausesc=true;
                    }

//
//                }
				}
				if (pausesc) ///pause screen running.
                {
                    pause.Render(frame,gRenderer);
                    pause.mouseMotionEvents(&e,gRenderer);

                    if (pause.getButtons()[0].getstate()==2)
                    {
                        Mix_PlayChannel( -1, gMedium, 0 );

                        gamesc=true;
                        pausesc=false;

                    }

                    if (pause.getButtons()[2].getstate()==2)
                    {
                        Mix_PlayChannel( -1, gMedium, 0 );

                        menusc=true;
                        pausesc=false;
                    }

                }
                if(gameover)
                {

                    gamefin.Render(frame,gRenderer);
                    gamefin.mouseMotionEvents(&e,gRenderer);
                    go.render(gRenderer);
                    if( Mix_PlayingMusic() == 0 )
                    {
                        Mix_PlayMusic( gMusic, -1 );
                    }

                    if(gamefin.getButtons()[2].getstate()==2)
                    {
                        Mix_PlayChannel( -1, gMedium, 0 );


                        gameover=false;
                        menusc=true;
                    }
                    if(gamefin.getButtons()[0].getstate()==2)
                    {
                        Mix_PlayChannel( -1, gMedium, 0 );

                        gameover=false;
                        gamesc=true;
                    }

                }

				SDL_RenderPresent( gRenderer );
			}
		}
	}
	}

	//Free resources and close SDL
	close();

	return 0;
}

