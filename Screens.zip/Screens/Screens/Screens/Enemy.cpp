#include "Enemy.h"

Enemy::Enemy(LTexture* k):Player(k)
{
    mPosX = 0;
    mPosY = base;
    ENEMY_WIDTH = 62;
    ENEMY_HEIGHT = 100;
    mVelX = 0.1;
    mVelY = 0;
    mCollider.w=ENEMY_WIDTH;
    mCollider.h=ENEMY_HEIGHT;
    checkJump = false;
    enemytexture = k;
}

void Enemy::move()
{
    mPosX += mVelX;
    mCollider.x=mPosX;

    mPosY += mVelY;
    mCollider.y=mPosY;

    if( ( mPosY < 0 ) || ( mPosY + ENEMY_HEIGHT > 600))
    {
        mPosY -= mVelY;
        mCollider.y=mPosY;
    }
}

void Enemy::runRender(int camx,SDL_Rect r, SDL_Renderer* gRenderer)
{
    enemytexture->Render(mPosX-camx,mPosY, &r, 0.0, NULL, SDL_FLIP_NONE, gRenderer   );
}

