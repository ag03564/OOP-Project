#pragma once
#include "Screen.h"

class gameoverScreen:public Screen
{
private:
    LTexture* buttonScreen; //the small screen over which buttons are drawn
public:
    gameoverScreen(LTexture*,LTexture*,LTexture*);
    void Render(long int& frame,SDL_Renderer*);
    virtual ~gameoverScreen();
};
