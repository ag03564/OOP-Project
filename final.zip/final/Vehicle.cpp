#include "Vehicle.h"


Vehicle::Vehicle()
{

}

Vehicle::~Vehicle()
{
    cout<<"Vehicle Deallocated"<<endl;
    //spriteSheetTexture = NULL;
}

Vehicle::Vehicle(LTexture* image, SDL_Rect r, float x, float y):Unit(image,r,x,y)
{
    this->x=x;
    this->y=y;
    spriteSheetTexture = image;
    src=r;
    alive = true;
    this->vv.x=this->x;
    this->vv.y=this->y;
    this->vv.w=r.w;
    this->vv.h=r.h;

}


void Vehicle::Move()
{
    x=x-speed;
    vv.x=x;

    if ( x < -1000)
        SetAlive(false);
}


void Vehicle::Move(float d)
{
    x=d;
    vv.x=x;
}
void Vehicle::Render(SDL_Renderer* gRenderer)
{
    //  cout<"K";
    spriteSheetTexture->Render( x, y, &src, 0.0, NULL, SDL_FLIP_NONE, gRenderer );
}

void Vehicle::Run()
{
    x=x+speed;
}

void Vehicle::jump()
{
    //mPosY = -50;

    y-=2;
    vv.y=y;

    //mPosY += mVelY;
}

void Vehicle::fall()
{
    y+=2;
    vv.y=y;

    // mPosY += mVelY;
}

bool Vehicle::isJump(SDL_Event& e)
{

    if( e.type == SDL_KEYDOWN)
    {
        //Adjust the velocity
        switch( e.key.keysym.sym )
        {
        case SDLK_UP:
            checkJump = true;
            break;
        }
    }
    //If a key was released

    return checkJump;
}
