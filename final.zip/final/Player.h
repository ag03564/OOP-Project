#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <iostream>
#include "LTexture.h"
class Player
{
public:
    //The dimensions of the dot
    static const int PLAYER_WIDTH = 62;
    static const int PLAYER_HEIGHT = 100;
    int SCREEN_WIDTH = 1400;
    int SCREEN_HEIGHT = 800;
    const int base = 435;
    //Maximum axis velocity of the dot
    const float PLAYER_VEL = 0.3;
    //Initializes the variables
    Player(LTexture*);
    LTexture* playertexture;
    //Takes key presses and adjusts the dot's velocity
    void handleEvent( SDL_Event& e );
    bool isAlive = false;
    int health = 0;
    //Moves the dot
    void move();
    void jump();
    void fall();
    bool checkJump;
    void loseHealth();
    //Shows the dot on the screen
    void runRender(int,SDL_Rect,SDL_Renderer*);
    void standRender(int,SDL_Rect,SDL_Renderer*);
    SDL_Rect mCollider;
    bool checkRun(SDL_Event& e);
    bool isJump(SDL_Event& e);

    //The X and Y offsets of the dot
    float mPosX, mPosY;

    //The velocity of the dot
    float mVelX, mVelY;
};
