#include "Obstacle.h"


Obstacle::Obstacle()
{

}

Obstacle::~Obstacle()
{
    cout<<"Obstacle Deallocated"<<endl;
    //spriteSheetTexture = NULL;
}

Obstacle::Obstacle(LTexture* image, SDL_Rect r, float x, float y, int m):Unit(image,r,x,y)
{
    this->x=x;
    this->y=y;
    spriteSheetTexture = image;
    src=r;
    mark=m;
    //friction = 0.95f;
    //speedx = 0;
    //speedy = 0;
    alive = true;
    coll.x=this->x;
    coll.y=this->y;
    coll.w=r.w;
    coll.h=r.h;
}


void Obstacle::Move()
{
    if ( x < -400)
    {
        SetAlive(false);

    }
}


void Obstacle::Move(int d)
{
    x=x-d;
    coll.x=this->x;
    coll.y=y;
}
void Obstacle::Render(SDL_Renderer* gRenderer)
{
  //  cout<"K";
    spriteSheetTexture->Render( x, y, &src,gRenderer );
}
