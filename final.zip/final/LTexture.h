#pragma once
#include "string"
#include "iostream"
#include "SDL.h"
#include "SDL_image.h"
#include <stdio.h>

class LTexture
{
public:
    LTexture();
    ~LTexture();
    //Loads image at specified path
    bool LoadFromFile( std::string path, SDL_Renderer* gRenderer);
    //Deallocates texture
    void Free();
    //Renders texture at given point
    void Render( int x, int y, SDL_Rect* clip,SDL_Renderer* gRenderer );
    //Gets image dimensions
    int GetWidth();
    int GetHeight();
    void SetWidth(int);
    void SetHeight(int);
private:
    //The actual hardware texture
    SDL_Texture* mTexture;
    //Image dimensions
    int mWidth;
    int mHeight;

};
