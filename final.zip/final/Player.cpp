#include "Player.h"

Player::Player(LTexture* p)
{
    //Initialize the offsets
    mPosX = 100;
    mPosY = base;

    //Initialize the velocity
    mVelX = 0;
    mVelY = 0;
    mCollider.x=mPosX;
    mCollider.y=mPosY;
    mCollider.w = PLAYER_WIDTH;
    mCollider.h = PLAYER_HEIGHT;
    checkJump = false;
    isAlive = true;
    health = 7;
    playertexture=p;
}

void Player::handleEvent( SDL_Event& e )
{
    //If a key was pressed
    if( e.type == SDL_KEYDOWN && e.key.repeat == 0 )
    {
        //Adjust the velocity
        switch( e.key.keysym.sym )
        {
        case SDLK_DOWN:
            mVelY += PLAYER_VEL;
            break;
        case SDLK_LEFT:
            mVelX -= PLAYER_VEL;
            break;
        case SDLK_RIGHT:
            mVelX += PLAYER_VEL;
            break;
        }
    }
    //If a key was released
    else if( e.type == SDL_KEYUP && e.key.repeat == 0 )
    {
        //Adjust the velocity
        switch( e.key.keysym.sym )
        {
        case SDLK_DOWN:
            mVelY -= PLAYER_VEL;
            break;
        case SDLK_LEFT:
            mVelX += PLAYER_VEL;
            break;
        case SDLK_RIGHT:
            mVelX -= PLAYER_VEL;
            break;
        }
    }
}

void Player::move()
{
    //Move the dot left or right
    if (mPosY == base)
    {
    mPosX += mVelX;
    mCollider.x = mPosX;
    }


    //If the dot went too far to the left or right
    if(( mPosX < 0 ) || ( mPosX + PLAYER_WIDTH > 800 ))
    {
        //Move back
        mPosX -= mVelX;
        mCollider.x = mPosX;
    }

    //Move the dot up or down
    mPosY += mVelY;
    mCollider.y=mPosY;

    //If the dot went too far up or down
    if( ( mPosY < 0 ) || ( mPosY + PLAYER_HEIGHT > 600) )
    {
        //Move back
        mPosY -= mVelY;
        mCollider.y -= mPosY;
    }
}

void Player::jump()
{
    //mPosY = -50;

    mPosY-=2;
    mCollider.y-=2;
    //mPosY += mVelY;
}

void Player::fall()
{
    mPosY+=2;
    mCollider.y+=2;

    // mPosY += mVelY;
}

bool Player::checkRun(SDL_Event& e)
{
    bool run = false;
    if( e.type == SDL_KEYDOWN)
    {
        run = true;
    }
    //If a key was released
    else if( e.type == SDL_KEYUP)
    {
        run = false;
    }
    return run;
}

bool Player::isJump(SDL_Event& e)
{

    if( e.type == SDL_KEYDOWN)
    {
        //Adjust the velocity
        switch( e.key.keysym.sym )
        {
        case SDLK_UP:
            checkJump = true;
            break;
        }
    }
    //If a key was released

    return checkJump;
}

void Player :: loseHealth()
{
    health-=1;
    if (health == 0)
    {
        isAlive = false;
    }
}

void Player::runRender(int camx,SDL_Rect r,SDL_Renderer* gRenderer)
{
    //Current animation frame
    //SDL_Rect* currentClip = &gSpriteClips[ frame / 6 ];
    playertexture->Render( mPosX,mPosY, &r, 0.0, NULL, SDL_FLIP_NONE, gRenderer  );
}

void Player::standRender(int camx,SDL_Rect r,SDL_Renderer* gRenderer)
{
    //SDL_Rect* currentClip = &gSpriteClips[5];
    playertexture->Render( mPosX,mPosY, &r, 0.0, NULL, SDL_FLIP_NONE, gRenderer  );
}
