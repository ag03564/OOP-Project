#include "Vehicle.h"


Vehicle::Vehicle()
{

}

Vehicle::~Vehicle()
{
    cout<<"Vehicle Deallocated"<<endl;
    //spriteSheetTexture = NULL;
}

Vehicle::Vehicle(LTexture* image, SDL_Rect r, float x, float y):Unit(image,r,x,y)
{
    this->x=x;
    this->y=y;
    spriteSheetTexture = image;
    src=r;
    //friction = 0.95f;
    //speedx = 0;
    //speedy = 0;
    alive = true;
}


void Vehicle::Move()
{
    x=x-speed;
    if ( x < -1000)
        SetAlive(false);
}


void Vehicle::Move(float d)
{
    x=x+d;
}
void Vehicle::Render(SDL_Renderer* gRenderer)
{
  //  cout<"K";
    spriteSheetTexture->Render( x, y, &src, 0.0, NULL, SDL_FLIP_NONE, gRenderer );
}

void Vehicle::Run()
{
    x=x+speed;
}
