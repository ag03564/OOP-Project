#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <iostream>
#include "LTexture.h"
class Player
{
    public:
		//The dimensions of the dot
		static const int PLAYER_WIDTH = 20;
		static const int PLAYER_HEIGHT = 20;

		//Maximum axis velocity of the dot
		static const float PLAYER_VEL = 0.03;
        static const int base = 435;


        const int SCREEN_WIDTH = 800;
        SDL_Renderer* gRenderer = NULL;
        const int SCREEN_HEIGHT = 600;
        int frame = 0;
        LTexture gSpriteSheetTexture;
        static const int WALKING_ANIMATION_FRAMES = 6;
        SDL_Rect gSpriteClips[ WALKING_ANIMATION_FRAMES ];
		//Initializes the variables
		Player();

		//Takes key presses and adjusts the dot's velocity
		void handleEvent( SDL_Event& e );

		//Moves the dot
		void move();
		void jump();
		void fall();
		bool checkJump;

		//Shows the dot on the screen
		void runRender();
		void standRender();

		bool checkRun(SDL_Event& e);
		bool isJump(SDL_Event& e);

		//The X and Y offsets of the dot
		float mPosX, mPosY;

		//The velocity of the dot
		float mVelX, mVelY;
};
