#pragma once
#include"Unit.h"

class Vehicle:public Unit
{
    const float speed=1;
public:
    Vehicle(LTexture* image, SDL_Rect r, float x, float y);
    Vehicle();
    virtual ~Vehicle();
    SDL_Rect vv;
    void jump();
    void fall();
    bool checkJump;
    bool checkRun(SDL_Event& e);
    bool isJump(SDL_Event& e);
//    void SetAlive(bool);
//    bool GetAlive();
//    int GetWidth();
//    int GetHeight();
//    float GetX();
//    float GetY();

    virtual void Run();
    virtual void Move(float);
    virtual void Move();
    virtual void Render(SDL_Renderer* gRenderer);
};

